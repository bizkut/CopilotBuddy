﻿using System;
using System.Linq;
using CommonBehaviors.Actions;
using Singular.Settings;
using Singular;

using Styx;
using Styx.Helpers;
using Styx.Logic.Combat;
using Styx.Logic.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;

using TreeSharp;

using Action = TreeSharp.Action;

namespace Singular.Helpers
{
    internal static class Movement
    {
        /// <summary>
        ///  Creates a behavior that does nothing more than check if we're in Line of Sight of the target; and if not, move towards the target.
        /// </summary>
        /// <remarks>
        ///  Created 23/5/2011
        /// </remarks>
        /// <returns>.</returns>
        public static Composite CreateMoveToLosBehavior()
        {
            return CreateMoveToLosBehavior(ret => StyxWoW.Me.CurrentTarget);
        }

       

        /// <summary>
        ///   Creates the ensure movement stopped behavior. Will return RunStatus.Success if it has stopped any movement, RunStatus.Failure otherwise.
        /// </summary>
        /// <remarks>
        ///   Created 5/1/2011.
        /// </remarks>
        /// <returns>.</returns>
        public static Composite CreateEnsureMovementStoppedBehavior()
        {
            return new Decorator(
                ret => !SingularSettings.Instance.DisableAllMovement && StyxWoW.Me.IsMoving,
                new Action(ret => Navigator.PlayerMover.MoveStop()));
        }

        /// <summary>
        /// Creates behavior to stop movement when within range of target.
        /// Essential for ranged classes to stop moving when in cast range.
        /// </summary>
        public static Composite CreateEnsureMovementStoppedWithinRange(float range)
        {
            return new Decorator(
                ret => !SingularSettings.Instance.DisableAllMovement && 
                       StyxWoW.Me.IsMoving && 
                       StyxWoW.Me.CurrentTarget != null &&
                       StyxWoW.Me.CurrentTarget.Distance <= range,
                new Action(ret => Navigator.PlayerMover.MoveStop()));
        }

        /// <summary>
        ///   Creates a behavior that does nothing more than check if we're facing the target; and if not, faces the target. (Uses a hard-coded 70degree frontal cone)
        /// </summary>
        /// <remarks>
        ///   Created 5/1/2011.
        /// </remarks>
        /// <returns>.</returns>
        public static Composite CreateFaceTargetBehavior()
        {
            return CreateFaceTargetBehavior(ret => StyxWoW.Me.CurrentTarget);
        }

        public static Composite CreateFaceTargetBehavior(UnitSelectionDelegate toUnit)
        {
            return new Decorator(
                ret =>
                !SingularSettings.Instance.DisableAllMovement && toUnit != null && toUnit(ret) != null && 
                !StyxWoW.Me.IsMoving && !toUnit(ret).IsMe && 
                !StyxWoW.Me.IsSafelyFacing(toUnit(ret), 70f),
                new Action(ret =>
                               {
                                   WoWUnit unit = toUnit(ret);
                                   unit.Face();

                                   // Prevent lower-priority cast actions from firing while still turning.
                                   // This mirrors newer Singular behavior and avoids visible cast-spam on behind targets.
                                   if (StyxWoW.Me.IsSafelyFacing(unit, 150f))
                                       return RunStatus.Failure;

                                   return RunStatus.Success;
                               }));
        }

        /// <summary>
        /// True when a hostile cast target differs from CurrentTarget and needs target/face before casting.
        /// Fixes multi-dot spread (e.g. Balance Moonfire on mob behind player) where CreateFaceTargetBehavior
        /// only faces CurrentTarget. Skips self, friendlies, and in-progress casts.
        /// </summary>
        public static bool NeedsOffTargetCastSetup(WoWUnit unit)
        {
            if (unit == null || unit.IsMe || unit.IsFriendly)
                return false;

            if (StyxWoW.Me.IsCasting)
                return false;

            return StyxWoW.Me.CurrentTarget != unit;
        }

        /// <summary>
        /// Target and face a hostile off-target unit before casting. Use only when NeedsOffTargetCastSetup is true.
        /// Success = ready to cast; Failure = retry next pulse (target switch or still turning).
        /// </summary>
        public static Composite CreateEnsureTargetAndFaceBehavior(UnitSelectionDelegate toUnit)
        {
            return new Action(ret =>
            {
                if (toUnit == null || toUnit(ret) == null)
                    return RunStatus.Failure;

                var unit = toUnit(ret);

                if (!NeedsOffTargetCastSetup(unit))
                    return RunStatus.Success;

                // Switch target to the cast unit
                if (StyxWoW.Me.CurrentTarget != unit)
                {
                    Logger.WriteDebug("Off-target cast: switching to " + unit.SafeName());
                    unit.Target();
                    return RunStatus.Failure;
                }

                // Face before casting — prevents cast failures on mobs behind the player
                if (!SingularSettings.Instance.DisableAllMovement && !StyxWoW.Me.IsMoving &&
                    !StyxWoW.Me.IsSafelyFacing(unit, 70f))
                {
                    Logger.WriteDebug("Off-target cast: facing " + unit.SafeName());
                    unit.Face();
                    return RunStatus.Failure;
                }

                return RunStatus.Success;
            });
        }

        /// <summary>
        ///   Creates a move to target behavior. Will return RunStatus.Success if it has reached the location, or stopped in range. Best used at the end of a rotation.
        /// </summary>
        /// <remarks>
        ///   Created 5/1/2011.
        /// </remarks>
        /// <param name = "stopInRange">true to stop in range.</param>
        /// <param name = "range">The range.</param>
        /// <returns>.</returns>
        public static Composite CreateMoveToTargetBehavior(bool stopInRange, float range)
        {
            return CreateMoveToTargetBehavior(stopInRange, range, ret => StyxWoW.Me.CurrentTarget);
        }

        /// <summary>
        ///   Creates a move to target behavior. Will return RunStatus.Success if it has reached the location, or stopped in range. Best used at the end of a rotation.
        /// </summary>
        /// <remarks>
        ///   Created 5/1/2011.
        /// </remarks>
        /// <param name = "stopInRange">true to stop in range.</param>
        /// <param name = "range">The range.</param>
        /// <param name="onUnit">The unit to move to.</param>
        /// <returns>.</returns>
        public static Composite CreateMoveToTargetBehavior(bool stopInRange, float range, UnitSelectionDelegate onUnit)
        {
            return 
                new Decorator(
                    ret => onUnit != null && onUnit(ret) != null && onUnit(ret) != StyxWoW.Me && !StyxWoW.Me.IsCasting,
                    CreateMoveToLocationBehavior(ret => onUnit(ret).Location, stopInRange, ret => range));
        }

        /// <summary>
        ///   Creates a move to melee range behavior. Will return RunStatus.Success if it has reached the location, or stopped in range. Best used at the end of a rotation.
        /// </summary>
        /// <remarks>
        ///   Created 5/1/2011.
        /// </remarks>
        /// <param name = "stopInRange">true to stop in range.</param>
        /// <param name = "range">The range.</param>
        /// <returns>.</returns>
        public static Composite CreateMoveToMeleeBehavior(bool stopInRange)
        {
            return new Decorator(
                ret => StyxWoW.Me.CurrentTarget != null,
                CreateMoveToMeleeBehavior(ret => StyxWoW.Me.CurrentTarget.Location, stopInRange));
        }

        public static Composite CreateMoveToMeleeBehavior(LocationRetriever location, bool stopInRange)
        {
            return 
                new Decorator(
                    ret => !StyxWoW.Me.IsCasting,
                    CreateMoveToLocationBehavior(location, stopInRange, ret => StyxWoW.Me.CurrentTarget?.IsPlayer == true ? 2f : Spell.MeleeRange));
        }

        #region Move Behind

        /// <summary>
        ///   Creates a move behind target behavior. If it cannot fully navigate will move to target location
        /// </summary>
        /// <remarks>
        ///   Created 2/12/2011.
        /// </remarks>
        /// <returns>.</returns>
        public static Composite CreateMoveBehindTargetBehavior()
        {
            return CreateMoveBehindTargetBehavior(ret => true);
        }

        /// <summary>
        ///   Creates a move behind target behavior. If it cannot fully navigate will move to target location
        /// </summary>
        /// <remarks>
        ///   Created 2/12/2011.
        /// </remarks>
        /// <param name="requirements">Aditional requirments.</param>
        /// <returns>.</returns>
        public static Composite CreateMoveBehindTargetBehavior(SimpleBooleanDelegate requirements)
        {
            return 
                new Decorator(
                    ret => !SingularSettings.Instance.DisableAllMovement &&
                            SingularRoutine.CurrentWoWContext != WoWContext.Battlegrounds && 
                            requirements(ret) && !StyxWoW.Me.IsCasting &&
                            !Group.MeIsTank && !StyxWoW.Me.CurrentTarget.MeIsBehind &&
                            StyxWoW.Me.CurrentTarget.IsAlive &&
                            (StyxWoW.Me.CurrentTarget.CurrentTarget == null || 
                             StyxWoW.Me.CurrentTarget.CurrentTarget != StyxWoW.Me || 
                             StyxWoW.Me.CurrentTarget.Stunned),
                    new Action(ret => Navigator.MoveTo(CalculatePointBehindTarget())));
        }

        private static WoWPoint CalculatePointBehindTarget()
        {
            return
                StyxWoW.Me.CurrentTarget.Location.RayCast(
                    StyxWoW.Me.CurrentTarget.Rotation + WoWMathHelper.DegreesToRadians(150), Spell.MeleeRange - 2f);
        }

        #endregion

        #region Root Move To Location

        /// <summary>
        ///   Creates a move to location behavior. Will return RunStatus.Success if it has reached the location, or stopped in range. Best used at the end of a rotation.
        /// </summary>
        /// <remarks>
        ///   Created 5/1/2011.
        /// </remarks>
        /// <param name = "location">The location.</param>
        /// <param name = "stopInRange">true to stop in range.</param>
        /// <param name = "range">The range.</param>
        /// <returns>.</returns>
        public static Composite CreateMoveToLocationBehavior(LocationRetriever location, bool stopInRange, DynamicRangeRetriever range)
        {
            // Do not fuck with this. It will ensure we stop in range if we're supposed to.
            // Otherwise it'll stick to the targets ass like flies on dog shit.
            // Specifying a range of, 2 or so, will ensure we're constantly running to the target. Specifying 0 will cause us to spin in circles around the target
            // or chase it down like mad. (PVP oriented behavior)
            return
                new Decorator( 
                    // Don't run if the movement is disabled.
                    ret => !SingularSettings.Instance.DisableAllMovement,
                    new PrioritySelector(
                        new Decorator(
                            // Give it a little more than 1/2 a yard buffer to get it right. CTM is never 'exact' on where we land. So don't expect it to be.
                            ret => stopInRange && StyxWoW.Me.Location.Distance(location(ret)) < range(ret),
                            new PrioritySelector(
                                CreateEnsureMovementStoppedBehavior(),
                                // In short; if we're not moving, just 'succeed' here, so we break the tree.
                                new Action(ret => RunStatus.Success)
                                )
                            ),
                        new Action(ret => Navigator.MoveTo(location(ret)))
                        ));
        }

        #endregion

        public static Composite CreateMoveToLosBehavior(UnitSelectionDelegate toUnit)
        {
            return new Decorator(
                ret =>
                !SingularSettings.Instance.DisableAllMovement && toUnit != null && toUnit(ret) != null && 
                toUnit(ret) != StyxWoW.Me && !toUnit(ret).InLineOfSpellSight,
                new Action(ret => Navigator.MoveTo(toUnit(ret).Location)));
        }

    }

    public delegate WoWPoint LocationRetriever(object context);

    public delegate float DynamicRangeRetriever(object context);
}