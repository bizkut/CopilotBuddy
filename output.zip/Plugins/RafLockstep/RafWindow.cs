using System;
using System.Collections.Generic;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;
using Styx.Helpers;

namespace Styx.Bot.Plugins.Raf
{
    public class RafWindow : Window
    {
        private static readonly Brush Ink = new SolidColorBrush(Color.FromRgb(0xE8, 0xE8, 0xE8));
        private static readonly Brush Muted = new SolidColorBrush(Color.FromRgb(0x9A, 0x9A, 0x9A));
        private static readonly Brush Panel = new SolidColorBrush(Color.FromRgb(0x2B, 0x2B, 0x2B));
        private static readonly Brush Ground = new SolidColorBrush(Color.FromRgb(0x1E, 0x1E, 0x1E));
        private static readonly Brush Good = new SolidColorBrush(Color.FromRgb(0x7B, 0xC8, 0x6C));
        private static readonly Brush Warn = new SolidColorBrush(Color.FromRgb(0xE0, 0xB0, 0x4C));

        private readonly RafLockstep _plugin;
        private readonly DispatcherTimer _timer;

        private CheckBox _enabled;
        private CheckBox _lockstep;
        private CheckBox _releaseAhead;
        private CheckBox _acceptGrants;
        private TextBox _pipeName;
        private TextBox _leash;
        private TextBox _maxHold;
        private TextBox _peerTimeout;

        private TextBlock _roleValue;
        private TextBlock _gateValue;
        private TextBlock _localValue;
        private ListView _peerList;
        private List<PeerSnapshot> _shownPeers;

        public RafWindow(RafLockstep plugin)
        {
            _plugin = plugin;

            Title = "RAF Lockstep";
            Width = 620;
            Height = 560;
            MinWidth = 520;
            MinHeight = 440;
            Background = Ground;
            WindowStartupLocation = WindowStartupLocation.CenterScreen;

            Content = BuildLayout();
            LoadFromSettings();

            _timer = new DispatcherTimer(DispatcherPriority.Background);
            _timer.Interval = TimeSpan.FromMilliseconds(500);
            _timer.Tick += (s, e) => RefreshStatus();
            _timer.Start();

            Closed += (s, e) => _timer.Stop();

            RefreshStatus();
        }

        private UIElement BuildLayout()
        {
            Grid root = new Grid();
            root.Margin = new Thickness(14);
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            UIElement status = BuildStatusPanel();
            Grid.SetRow(status, 0);
            root.Children.Add(status);

            UIElement settings = BuildSettingsPanel();
            Grid.SetRow(settings, 1);
            root.Children.Add(settings);

            UIElement peers = BuildPeerPanel();
            Grid.SetRow(peers, 2);
            root.Children.Add(peers);

            UIElement buttons = BuildButtonRow();
            Grid.SetRow(buttons, 3);
            root.Children.Add(buttons);

            return root;
        }

        private UIElement BuildStatusPanel()
        {
            Grid grid = new Grid();
            grid.Margin = new Thickness(0, 0, 0, 12);
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(84) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            AddStatusRow(grid, 0, "Link", out _roleValue);
            AddStatusRow(grid, 1, "Gate", out _gateValue);
            AddStatusRow(grid, 2, "This bot", out _localValue);

            Border border = new Border();
            border.Background = Panel;
            border.CornerRadius = new CornerRadius(4);
            border.Padding = new Thickness(12, 10, 12, 10);
            border.Child = grid;
            border.Margin = new Thickness(0, 0, 0, 12);
            return border;
        }

        private void AddStatusRow(Grid grid, int row, string label, out TextBlock value)
        {
            TextBlock caption = new TextBlock();
            caption.Text = label;
            caption.Foreground = Muted;
            caption.Margin = new Thickness(0, 2, 8, 2);
            Grid.SetRow(caption, row);
            Grid.SetColumn(caption, 0);
            grid.Children.Add(caption);

            value = new TextBlock();
            value.Foreground = Ink;
            value.TextWrapping = TextWrapping.Wrap;
            value.Margin = new Thickness(0, 2, 0, 2);
            Grid.SetRow(value, row);
            Grid.SetColumn(value, 1);
            grid.Children.Add(value);
        }

        private UIElement BuildSettingsPanel()
        {
            StackPanel stack = new StackPanel();
            stack.Margin = new Thickness(0, 0, 0, 12);

            _enabled = AddCheckBox(stack, "Enabled");
            _lockstep = AddCheckBox(stack, "Lock step on quest id");
            _releaseAhead = AddCheckBox(stack, "Do not wait on a peer that is ahead");
            _acceptGrants = AddCheckBox(stack, "Accept RAF level grants");

            Grid fields = new Grid();
            fields.Margin = new Thickness(0, 8, 0, 0);
            fields.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            fields.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            fields.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            fields.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            _leash = AddField(fields, 0, 0, "Leash range (yards)");
            _maxHold = AddField(fields, 0, 1, "Max hold (seconds, 0 = never)");
            _pipeName = AddField(fields, 1, 0, "Pipe name");
            _peerTimeout = AddField(fields, 1, 1, "Peer timeout (ms)");

            stack.Children.Add(fields);

            Border border = new Border();
            border.Background = Panel;
            border.CornerRadius = new CornerRadius(4);
            border.Padding = new Thickness(12, 10, 12, 12);
            border.Child = stack;
            border.Margin = new Thickness(0, 0, 0, 12);
            return border;
        }

        private CheckBox AddCheckBox(Panel parent, string label)
        {
            CheckBox box = new CheckBox();
            box.Content = label;
            box.Foreground = Ink;
            box.Margin = new Thickness(0, 3, 0, 3);
            parent.Children.Add(box);
            return box;
        }

        private TextBox AddField(Grid grid, int row, int column, string label)
        {
            StackPanel cell = new StackPanel();
            cell.Margin = new Thickness(column == 0 ? 0 : 8, 6, column == 0 ? 8 : 0, 0);

            TextBlock caption = new TextBlock();
            caption.Text = label;
            caption.Foreground = Muted;
            caption.Margin = new Thickness(0, 0, 0, 3);
            cell.Children.Add(caption);

            TextBox box = new TextBox();
            box.Padding = new Thickness(4, 3, 4, 3);
            cell.Children.Add(box);

            Grid.SetRow(cell, row);
            Grid.SetColumn(cell, column);
            grid.Children.Add(cell);
            return box;
        }

        private UIElement BuildPeerPanel()
        {
            _peerList = new ListView();
            _peerList.Background = Panel;
            _peerList.Foreground = Ink;
            _peerList.BorderThickness = new Thickness(0);

            GridView view = new GridView();
            view.Columns.Add(MakeColumn("Peer", "Name", 130));
            view.Columns.Add(MakeColumn("Lvl", "Level", 46));
            view.Columns.Add(MakeColumn("Intent", "Intent", 78));
            view.Columns.Add(MakeColumn("Quest", "QuestId", 74));
            view.Columns.Add(MakeColumn("In log", "HasQuest", 60));
            view.Columns.Add(MakeColumn("Done", "QuestCompleted", 58));
            view.Columns.Add(MakeColumn("Holding", "Holding", 66));
            _peerList.View = view;

            return _peerList;
        }

        private static GridViewColumn MakeColumn(string header, string path, double width)
        {
            GridViewColumn column = new GridViewColumn();
            column.Header = header;
            column.Width = width;
            column.DisplayMemberBinding = new System.Windows.Data.Binding(path);
            return column;
        }

        private UIElement BuildButtonRow()
        {
            StackPanel row = new StackPanel();
            row.Orientation = Orientation.Horizontal;
            row.HorizontalAlignment = HorizontalAlignment.Right;
            row.Margin = new Thickness(0, 12, 0, 0);

            Button save = new Button();
            save.Content = "Save";
            save.Width = 92;
            save.Padding = new Thickness(0, 4, 0, 4);
            save.Margin = new Thickness(0, 0, 8, 0);
            save.Click += (s, e) => SaveToSettings();
            row.Children.Add(save);

            Button close = new Button();
            close.Content = "Close";
            close.Width = 92;
            close.Padding = new Thickness(0, 4, 0, 4);
            close.Click += (s, e) => Close();
            row.Children.Add(close);

            return row;
        }

        private void LoadFromSettings()
        {
            RafSettings settings = RafSettings.Instance;

            _enabled.IsChecked = settings.Enabled;
            _lockstep.IsChecked = settings.LockstepQuests;
            _releaseAhead.IsChecked = settings.ReleaseOnPeerCompleted;
            _acceptGrants.IsChecked = settings.AcceptLevelGrants;

            _pipeName.Text = settings.PipeName;
            _leash.Text = settings.LeashRange.ToString(CultureInfo.InvariantCulture);
            _maxHold.Text = settings.MaxHoldSeconds.ToString(CultureInfo.InvariantCulture);
            _peerTimeout.Text = settings.PeerTimeoutMs.ToString(CultureInfo.InvariantCulture);
        }

        private void SaveToSettings()
        {
            try
            {
                RafSettings settings = RafSettings.Instance;

                settings.Enabled = _enabled.IsChecked == true;
                settings.LockstepQuests = _lockstep.IsChecked == true;
                settings.ReleaseOnPeerCompleted = _releaseAhead.IsChecked == true;
                settings.AcceptLevelGrants = _acceptGrants.IsChecked == true;

                settings.LeashRange = Clamp(ParseDouble(_leash.Text, settings.LeashRange), 5.0, 500.0);
                settings.MaxHoldSeconds = (int)Clamp(ParseInt(_maxHold.Text, settings.MaxHoldSeconds), 0, 3600);
                settings.PeerTimeoutMs = (int)Clamp(ParseInt(_peerTimeout.Text, settings.PeerTimeoutMs), 500, 60000);

                string pipe = (_pipeName.Text ?? string.Empty).Trim();
                bool pipeChanged = false;
                if (PeerLink.IsValidPipeName(pipe))
                {
                    pipeChanged = !string.Equals(pipe, settings.PipeName, StringComparison.Ordinal);
                    settings.PipeName = pipe;
                }
                else
                {
                    Logging.Write(Colors.Orange, "[RAF Lockstep] invalid pipe name, keeping the previous one.");
                }

                settings.Save();
                LoadFromSettings();

                if (pipeChanged)
                {
                    Logging.Write(Colors.Gold,
                        "[RAF Lockstep] pipe name changed, toggle the plugin off and on to rebind.");
                }
            }
            catch (Exception ex)
            {
                Logging.WriteException(ex);
            }
        }

        private void RefreshStatus()
        {
            try
            {
                _roleValue.Text = DescribeRole();
                _roleValue.Foreground = _plugin.Role == LinkRole.Offline ? Warn : Good;

                bool holding = _plugin.IsHolding;
                string reason = _plugin.GateReason;
                _gateValue.Text = holding
                    ? "holding - " + reason
                    : (string.IsNullOrEmpty(reason) ? "open" : "open - " + reason);
                _gateValue.Foreground = holding ? Warn : Good;

                PeerSnapshot local = _plugin.LocalSnapshot;
                _localValue.Text = local == null
                    ? "waiting for the game"
                    : string.Format(CultureInfo.InvariantCulture, "{0}  level {1}  {2}",
                        local.Name, local.Level, local.Describe());

                List<PeerSnapshot> peers = _plugin.GetPeers();
                if (PeerListChanged(peers))
                {
                    _shownPeers = peers;
                    _peerList.ItemsSource = peers;
                }
            }
            catch (Exception ex)
            {
                Logging.WriteException(ex);
            }
        }

        private string DescribeRole()
        {
            LinkRole role = _plugin.Role;
            string error = _plugin.LinkError;

            List<PeerSnapshot> peers = _plugin.GetPeers();
            string text = string.Format(CultureInfo.InvariantCulture, "{0}, {1} peer(s)", role, peers.Count);

            if (!string.IsNullOrEmpty(error))
                text += "  [" + error + "]";

            return text;
        }

        private bool PeerListChanged(List<PeerSnapshot> peers)
        {
            if (_shownPeers == null || _shownPeers.Count != peers.Count)
                return true;

            for (int i = 0; i < peers.Count; i++)
            {
                PeerSnapshot a = _shownPeers[i];
                PeerSnapshot b = peers[i];
                if (a.Name != b.Name || a.Level != b.Level || a.Intent != b.Intent
                    || a.QuestId != b.QuestId || a.HasQuest != b.HasQuest
                    || a.QuestCompleted != b.QuestCompleted || a.Holding != b.Holding)
                {
                    return true;
                }
            }

            return false;
        }

        private static double Clamp(double value, double min, double max)
        {
            return value < min ? min : (value > max ? max : value);
        }

        private static double ParseDouble(string text, double fallback)
        {
            double value;
            return double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out value) ? value : fallback;
        }

        private static int ParseInt(string text, int fallback)
        {
            int value;
            return int.TryParse(text, NumberStyles.Integer, CultureInfo.InvariantCulture, out value) ? value : fallback;
        }
    }
}
