using System;
using System.Collections.Generic;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using CopilotBuddy.Buddy.Overlay;
using CopilotBuddy.Buddy.Overlay.Controls;

namespace Styx.Bot.Plugins.Raf
{
    public class RafOverlay : OverlayUIComponent
    {
        private static readonly Brush Ink = Frozen(Color.FromRgb(0xF0, 0xF0, 0xF0));
        private static readonly Brush Muted = Frozen(Color.FromArgb(0xFF, 0xA8, 0xA8, 0xA8));
        private static readonly Brush Ground = Frozen(Color.FromArgb(0xC8, 0x14, 0x16, 0x1A));
        private static readonly Brush Edge = Frozen(Color.FromArgb(0x60, 0xFF, 0xFF, 0xFF));
        private static readonly Brush Good = Frozen(Color.FromRgb(0x6E, 0xC8, 0x62));
        private static readonly Brush Warn = Frozen(Color.FromRgb(0xE2, 0xB0, 0x48));
        private static readonly Brush Bad = Frozen(Color.FromRgb(0xD8, 0x5A, 0x50));

        private readonly RafLockstep _plugin;
        private readonly OverlayControl _control;

        private readonly Border _statusBar;
        private readonly TextBlock _statusText;
        private readonly TextBlock _reasonText;
        private readonly StackPanel _rows;

        public RafOverlay(RafLockstep plugin)
            : base(true)
        {
            _plugin = plugin;

            _statusText = MakeText(Ink, 13, FontWeights.SemiBold);
            _reasonText = MakeText(Muted, 11, FontWeights.Normal);
            _reasonText.TextWrapping = TextWrapping.Wrap;
            _reasonText.Margin = new Thickness(0, 2, 0, 0);

            _statusBar = new Border();
            _statusBar.Background = Good;
            _statusBar.CornerRadius = new CornerRadius(2);
            _statusBar.Height = 3;
            _statusBar.Margin = new Thickness(0, 0, 0, 8);

            _rows = new StackPanel();
            _rows.Margin = new Thickness(0, 8, 0, 0);

            StackPanel body = new StackPanel();
            body.Children.Add(_statusBar);
            body.Children.Add(_statusText);
            body.Children.Add(_reasonText);
            body.Children.Add(_rows);

            Border frame = new Border();
            frame.Background = Ground;
            frame.BorderBrush = Edge;
            frame.BorderThickness = new Thickness(1);
            frame.CornerRadius = new CornerRadius(5);
            frame.Padding = new Thickness(12, 10, 12, 10);
            frame.Child = body;

            _control = new OverlayControl();
            _control.AllowMoving = true;
            _control.AllowResizing = false;
            _control.X = 40;
            _control.Y = 120;
            _control.Width = 268;
            _control.Content = frame;
        }

        public override OverlayControl Control
        {
            get { return _control; }
        }

        protected override void Update()
        {
            try
            {
                PeerSnapshot local = _plugin.LocalSnapshot;
                List<PeerSnapshot> peers = _plugin.GetPeers();

                bool holding = _plugin.IsHolding;
                bool linked = _plugin.Role != LinkRole.Offline && peers.Count > 0;

                _statusBar.Background = !linked ? Bad : (holding ? Warn : Good);

                _statusText.Text = !linked
                    ? "RAF - no peer"
                    : (holding ? "RAF - holding" : "RAF - in step");
                _statusText.Foreground = !linked ? Bad : (holding ? Warn : Good);

                string reason = _plugin.GateReason;
                _reasonText.Text = string.IsNullOrEmpty(reason)
                    ? (linked ? "both bots on the same step" : "waiting for the other instance")
                    : reason;

                Compose(local, peers);
            }
            catch (Exception)
            {
            }
        }

        private void Compose(PeerSnapshot local, List<PeerSnapshot> peers)
        {
            int wanted = (local != null ? 1 : 0) + peers.Count;

            while (_rows.Children.Count > wanted)
                _rows.Children.RemoveAt(_rows.Children.Count - 1);
            while (_rows.Children.Count < wanted)
                _rows.Children.Add(NewRow());

            int index = 0;
            if (local != null)
                Fill((Grid)_rows.Children[index++], local, local, true);

            for (int i = 0; i < peers.Count; i++)
                Fill((Grid)_rows.Children[index++], peers[i], local, false);
        }

        private static Grid NewRow()
        {
            Grid grid = new Grid();
            grid.Margin = new Thickness(0, 3, 0, 0);
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            TextBlock who = MakeText(Ink, 12, FontWeights.Normal);
            Grid.SetColumn(who, 0);
            grid.Children.Add(who);

            TextBlock what = MakeText(Muted, 11, FontWeights.Normal);
            what.Margin = new Thickness(8, 1, 0, 0);
            Grid.SetColumn(what, 1);
            grid.Children.Add(what);

            return grid;
        }

        private static void Fill(Grid row, PeerSnapshot snapshot, PeerSnapshot local, bool isSelf)
        {
            TextBlock who = (TextBlock)row.Children[0];
            TextBlock what = (TextBlock)row.Children[1];

            who.Text = string.Format(CultureInfo.InvariantCulture, "{0}{1}  {2}",
                isSelf ? "> " : "  ", snapshot.Name, snapshot.Level);
            who.Foreground = snapshot.Dead ? Bad : (snapshot.Holding ? Warn : Ink);

            string state = snapshot.Describe();
            if (!isSelf && local != null)
            {
                float distance = local.DistanceTo(snapshot);
                state += distance == float.MaxValue
                    ? "  off map"
                    : string.Format(CultureInfo.InvariantCulture, "  {0:F0}y", distance);
            }

            what.Text = state;
            what.Foreground = snapshot.Dead ? Bad : Muted;
        }

        private static TextBlock MakeText(Brush brush, double size, FontWeight weight)
        {
            TextBlock text = new TextBlock();
            text.Foreground = brush;
            text.FontSize = size;
            text.FontWeight = weight;
            return text;
        }

        private static Brush Frozen(Color color)
        {
            SolidColorBrush brush = new SolidColorBrush(color);
            brush.Freeze();
            return brush;
        }
    }
}
