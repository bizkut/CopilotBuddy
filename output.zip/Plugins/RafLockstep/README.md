# RAF Lockstep

Keeps two Recruit-A-Friend accounts on the same quest so they never drift apart.

Written for CopilotBuddy on WoW 3.3.5a (build 12340).

## The problem it solves

Two accounts leveling together, each driven by its own CopilotBuddy instance running the same
profile. What ruins a RAF run is not distance, it is desync: the two characters end up working
different quests, walk to opposite NPCs, and the pair falls apart.

Checking proximity does not catch this. Two bots can stand next to each other while working
completely different quest nodes.

## Setup

1. Launch both WoW clients and both CopilotBuddy instances.
2. Log in both characters and put them in a party. Invite manually the first time; after that
   the plugin accepts invites on its own whenever the group breaks.
3. Load the same questing profile on both sides.
4. Enable the plugin on both, then **start the bot on both**. Plugins do not pulse while the
   bot is stopped, so nothing happens until you press Start.

Both instances must use the same pipe name. The default works, leave it alone unless you run
more than one pair on the same machine.

You do not need to add anyone to your friends list. The two instances talk over a local named
pipe between the two processes, not through the game.

## How it works

**The link.** Each instance opens a named pipe under the same name. Whoever starts first
creates the server and becomes Hub, the other connects and becomes Spoke. Every 400 ms they
exchange a snapshot: position, map, level, current quest, whether they are dead or in combat.
Hub and Spoke are transport roles only. They carry no meaning in game and can swap on any
restart.

**Reading the quest.** Every pulse the plugin reads `QuestOrder.Instance.CurrentBehavior` and
recognises PickUp, TurnIn, Objective, MoveTo and UseItem nodes, taking the quest id from each.
It reads `QuestOrder.Instance` rather than `QuestState.Instance.Order` on purpose: when a
profile enters an `<If>` or `<While>` body, a separate inner QuestOrder is built, and the outer
one stops reporting anything useful. Class branches are the most likely place for a RAF pair to
diverge, so that is exactly where the plugin has to keep seeing.

**The handshake.** Each snapshot also carries an answer about the other bot's quest: whether it
is in my log, and whether I have already completed it. The gate asks the peer instead of
guessing from its own quest log, which gives the wrong answer as soon as a quest is restricted
to one class or faction.

**The decision.** In order: a dead peer means wait. A peer past the leash range means wait, but
only one of the two waits, otherwise both freeze and nobody closes the gap. A peer that has not
done our quest yet means wait. A peer already further along means keep going.

**Errands do not count against the leash.** A peer reporting no active quest node - training a
new rank, vendoring, repairing, hearthing home, resting at an inn - is not treated as lost. The
leash range is ignored for that peer until a much larger hard leash range is crossed, so a short
side trip does not freeze the other bot or drag it along. Past the hard leash, waiting and
walking over resume regardless, so a genuinely lost partner is never ignored. A release margin
above the leash range also stops the gate from flapping open and closed when the distance sits
right on the line.

**Deciding who waits.** When neither peer can be shown to be ahead (same quest and intent, no
completion on either side to break the tie), the plugin used to always make the same character
wait, based on comparing character names. That has been replaced with a rotation: which
character yields swaps every few seconds (`Tie-break rotation`), so a persistent tie is shared
rather than permanently pinned on one name.

A breaker opens the gate after `MaxHoldSeconds` with a log line, so a desync can never deadlock
the run.

**Holding.** The plugin inserts a gate at the `Taxi_Check` tree hook. When it returns success
the whole bot tick is skipped, which stops questing while leaving death handling, combat,
looting and vendor runs alive. It does not clear POIs, stop movement or close frames. Plugins
pulse before the tree, so anything done that way is undone in the same frame and only creates
navmesh churn.

**Recovery.** Braking does not bring anyone closer. Past `FollowRange`, while the gate holds the
tree, the plugin navigates to the peer itself. The position comes from the pipe, not from the
object manager, so it still works when the partner is out of visibility range or on another
part of the map.

**Automation.** Three Lua events are handled: `LEVEL_GRANT_PROPOSED` accepts a level grant,
`CONFIRM_SUMMON` accepts a summon, `PARTY_INVITE_REQUEST` accepts a party invite. A summon is
the only real recovery action available, it ends a desync in one step.

**Display.** The Settings button opens a window with the link state, the gate reason and the
peer list. The in-game overlay draws the same thing over the client and can be dragged with the
mouse. Green means in step, amber means holding, red means no peer.

## Settings

| Setting | Default | What it does |
|---|---|---|
| Enabled | true | Master switch |
| Pipe name | CopilotBuddy.RafLockstep | Must match on both instances |
| Peer timeout (ms) | 3000 | A peer silent this long is treated as gone |
| Leash range | 30 | Distance past which the bot ahead waits |
| Lock step on quest id | true | Hold when the peers are on different quests |
| Do not wait on a peer that is ahead | true | Only wait on a peer that is behind |
| Max hold (seconds) | 90 | Fail open after this long, 0 disables |
| Walk back to a lost partner | true | Navigate to the peer instead of standing still |
| Follow beyond (yards) | 60 | Distance past which holding turns into walking |
| Ignore leash while peer is on an errand | true | A peer with no active quest node (training, vendoring, hearthing, resting) can drift past the leash range without holding or being followed |
| Hard leash range | 120 | Distance past which the bot always waits and walks over, even during a peer's errand |
| Leash release margin | 8 | Extra yards the peer must close before a distance hold is lifted, to stop rapid holding/resuming right at the leash line |
| Tie-break rotation (seconds) | 20 | When neither peer is provably ahead, which one yields rotates on this interval instead of always being the same character |
| Accept level grants | true | Auto accept a RAF level grant |
| Accept summons | true | Auto confirm a Summon Friend |
| Accept party invites | true | Auto accept a party invite |
| Show the in-game overlay | true | Draw the widget over the client |

Settings live in `Settings\RafLockstep.xml`, one file shared by both instances on the same
machine.

## If something looks wrong

**No overlay.** The bot has to be started, not just the plugin enabled. Check the log for
`overlay attached`. If you see `overlay could not be created`, the overlay system itself is
unavailable, usually because Desktop Composition is off in Windows.

**Overlay says no peer.** Open the settings window and read the Link line. It shows Hub or
Spoke, the peer count, and the pipe error if there is one. Check both sides use the same pipe
name, and that both bots are actually started.

**Both bots stand still.** Should not happen, only one side ever waits. If it does, look at the
gate reason on each side. After `MaxHoldSeconds` both fail open on their own.

**Changing a setting does nothing.** Changing the pipe name needs the plugin toggled off and on
to rebind. Changing the plugin source needs CopilotBuddy restarted, since plugins are compiled
at load time.

## Known limits

The two instances must run on the same machine, the pipe is local.

Nothing sends a party invite. The plugin only accepts one, so form the group manually the first
time.

The gate only understands quest nodes. Time spent in CustomBehavior blocks is invisible to it,
and there the pair is on proximity alone.

Not tested in a long unattended run yet. Report what you see in the log.
