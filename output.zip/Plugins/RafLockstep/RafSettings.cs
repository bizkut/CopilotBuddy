using System.ComponentModel;
using System.IO;
using Styx.Helpers;
using DefaultValue = Styx.Helpers.DefaultValueAttribute;

namespace Styx.Bot.Plugins.Raf
{
    public class RafSettings : Settings
    {
        private static RafSettings _instance;

        public RafSettings()
            : base(Path.Combine(Path.Combine(Logging.ApplicationPath, "Settings"), "RafLockstep.xml"))
        {
        }

        public static RafSettings Instance
        {
            get { return _instance ?? (_instance = new RafSettings()); }
        }

        [Setting]
        [DefaultValue(true)]
        [Category("General")]
        [DisplayName("Enabled")]
        [Description("Master switch. When off the plugin never holds the bot.")]
        public bool Enabled { get; set; }

        [Setting]
        [DefaultValue("CopilotBuddy.RafLockstep")]
        [Category("Link")]
        [DisplayName("Pipe name")]
        [Description("Named pipe shared by every CopilotBuddy instance of the same RAF team.")]
        public string PipeName { get; set; }

        [Setting]
        [DefaultValue(3000)]
        [Category("Link")]
        [DisplayName("Peer timeout (ms)")]
        [Description("A peer that has not reported within this window is treated as gone.")]
        public int PeerTimeoutMs { get; set; }

        [Setting]
        [DefaultValue(30.0)]
        [Category("Gate")]
        [DisplayName("Leash range (yards)")]
        [Description("Every party member must be within this distance before the bot may proceed.")]
        public double LeashRange { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("Gate")]
        [DisplayName("Lock step on quest id")]
        [Description("Hold until every peer reports the same quest and the same pickup or turn-in intent.")]
        public bool LockstepQuests { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("Gate")]
        [DisplayName("Release when peer already completed")]
        [Description("Do not wait on a peer that has already completed the quest we are working on.")]
        public bool ReleaseOnPeerCompleted { get; set; }

        [Setting]
        [DefaultValue(90)]
        [Category("Gate")]
        [DisplayName("Max hold (seconds)")]
        [Description("Fail open after holding this long so a desync can never deadlock the run. Zero disables the breaker.")]
        public int MaxHoldSeconds { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("Recruit a Friend")]
        [DisplayName("Accept level grants")]
        [Description("Automatically accept an incoming RAF level grant.")]
        public bool AcceptLevelGrants { get; set; }
        [Setting]
        [DefaultValue(true)]
        [Category("Recovery")]
        [DisplayName("Walk back to a lost partner")]
        [Description("While the gate holds, navigate to the peer instead of standing still.")]
        public bool FollowWhenLost { get; set; }

        [Setting]
        [DefaultValue(60.0)]
        [Category("Recovery")]
        [DisplayName("Follow beyond (yards)")]
        [Description("Distance past which holding turns into walking back to the peer.")]
        public double FollowRange { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("Recruit a Friend")]
        [DisplayName("Accept summons")]
        [Description("Automatically confirm an incoming Summon Friend.")]
        public bool AcceptSummons { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("Recruit a Friend")]
        [DisplayName("Accept party invites")]
        [Description("Automatically accept an incoming party invite.")]
        public bool AcceptPartyInvites { get; set; }

        [Setting]
        [DefaultValue(true)]
        [Category("Overlay")]
        [DisplayName("Show the in-game overlay")]
        [Description("Draw the pair status over the WoW window.")]
        public bool ShowOverlay { get; set; }
    }
}
