//!CompilerOption:AddRef:System.IO.Pipes.dll

using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Pipes;
using System.Text;
using System.Threading;

namespace Styx.Bot.Plugins.Raf
{
    public enum LinkRole
    {
        Offline = 0,
        Electing = 1,
        Hub = 2,
        Spoke = 3
    }

    public class PeerLink
    {
        private const int MaxServerInstances = 1;
        private const int ConnectTimeoutMs = 400;
        private const int ExchangeIntervalMs = 400;
        private const int RetryDelayMs = 1200;

        private readonly object _sync = new object();
        private readonly Dictionary<ulong, PeerSnapshot> _remote = new Dictionary<ulong, PeerSnapshot>();
        private readonly List<Stream> _openStreams = new List<Stream>();

        private string _pipeName = "CopilotBuddy.RafLockstep";
        private PeerSnapshot _local;
        private LinkRole _role;
        private Thread _worker;
        private int _generation;
        private string _lastError = string.Empty;

        public LinkRole Role
        {
            get { lock (_sync) { return _role; } }
        }

        public string LastError
        {
            get { lock (_sync) { return _lastError; } }
        }

        public static bool IsValidPipeName(string name)
        {
            if (string.IsNullOrWhiteSpace(name) || name.Length > 200)
                return false;
            return name.IndexOfAny(new[] { '\\', '/', ':', '*', '?', '"', '<', '>', '|' }) < 0;
        }

        public void Start(string pipeName)
        {
            Stop();

            int generation;
            lock (_sync)
            {
                _pipeName = IsValidPipeName(pipeName) ? pipeName.Trim() : "CopilotBuddy.RafLockstep";
                _remote.Clear();
                _role = LinkRole.Electing;
                _lastError = string.Empty;
                generation = ++_generation;
            }

            Thread worker = new Thread(() => Run(generation));
            worker.IsBackground = true;
            worker.Name = "RafLockstep.PeerLink";
            _worker = worker;
            worker.Start();
        }

        public void Stop()
        {
            Thread worker;

            lock (_sync)
            {
                _generation++;
                worker = _worker;
                _worker = null;

                for (int i = 0; i < _openStreams.Count; i++)
                    DisposeQuiet(_openStreams[i]);
                _openStreams.Clear();

                _remote.Clear();
                _role = LinkRole.Offline;
            }

            if (worker != null && worker.IsAlive)
                worker.Join(500);
        }

        public void Publish(PeerSnapshot snapshot)
        {
            lock (_sync) { _local = snapshot; }
        }

        public List<PeerSnapshot> GetPeers(int timeoutMs)
        {
            List<PeerSnapshot> result = new List<PeerSnapshot>();

            lock (_sync)
            {
                foreach (KeyValuePair<ulong, PeerSnapshot> entry in _remote)
                {
                    if (!entry.Value.IsStale(timeoutMs))
                        result.Add(entry.Value);
                }
            }

            return result;
        }

        private bool IsCurrent(int generation)
        {
            lock (_sync) { return _generation == generation; }
        }

        private string CurrentPipeName
        {
            get { lock (_sync) { return _pipeName; } }
        }

        private PeerSnapshot CurrentLocal
        {
            get { lock (_sync) { return _local; } }
        }

        private void SetRole(int generation, LinkRole role)
        {
            lock (_sync)
            {
                if (_generation == generation)
                    _role = role;
            }
        }

        private void SetError(int generation, string message)
        {
            lock (_sync)
            {
                if (_generation == generation)
                    _lastError = message ?? string.Empty;
            }
        }

        private void Track(Stream stream)
        {
            lock (_sync) { _openStreams.Add(stream); }
        }

        private void Untrack(Stream stream)
        {
            lock (_sync) { _openStreams.Remove(stream); }
        }

        private void Absorb(int generation, PeerSnapshot snapshot)
        {
            if (snapshot == null || snapshot.Guid == 0UL)
                return;

            lock (_sync)
            {
                if (_generation != generation)
                    return;
                if (_local != null && _local.Guid == snapshot.Guid)
                    return;
                _remote[snapshot.Guid] = snapshot;
            }
        }

        private List<PeerSnapshot> KnownExcept(ulong guid)
        {
            List<PeerSnapshot> result = new List<PeerSnapshot>();

            lock (_sync)
            {
                if (_local != null && _local.Guid != guid)
                    result.Add(_local);

                foreach (KeyValuePair<ulong, PeerSnapshot> entry in _remote)
                {
                    if (entry.Key != guid)
                        result.Add(entry.Value);
                }
            }

            return result;
        }

        private void ReplaceRemote(int generation, List<PeerSnapshot> snapshots)
        {
            lock (_sync)
            {
                if (_generation != generation)
                    return;

                _remote.Clear();
                foreach (PeerSnapshot snapshot in snapshots)
                {
                    if (_local != null && _local.Guid == snapshot.Guid)
                        continue;
                    _remote[snapshot.Guid] = snapshot;
                }
            }
        }

        private void Run(int generation)
        {
            while (IsCurrent(generation))
            {
                try
                {
                    if (!TryRunAsSpoke(generation))
                        TryRunAsHub(generation);
                }
                catch (Exception ex)
                {
                    SetError(generation, ex.Message);
                }

                if (IsCurrent(generation))
                {
                    SetRole(generation, LinkRole.Electing);
                    Thread.Sleep(RetryDelayMs);
                }
            }

            SetRole(generation, LinkRole.Offline);
        }

        private bool TryRunAsSpoke(int generation)
        {
            NamedPipeClientStream client = null;

            try
            {
                client = new NamedPipeClientStream(".", CurrentPipeName, PipeDirection.InOut, PipeOptions.CurrentUserOnly);
                client.Connect(ConnectTimeoutMs);
            }
            catch (Exception)
            {
                DisposeQuiet(client);
                return false;
            }

            Track(client);
            SetRole(generation, LinkRole.Spoke);
            SetError(generation, string.Empty);

            try
            {
                using (StreamReader reader = new StreamReader(client, new UTF8Encoding(false), false, 1024, true))
                using (StreamWriter writer = new StreamWriter(client, new UTF8Encoding(false), 1024, true))
                {
                    writer.AutoFlush = true;

                    while (IsCurrent(generation) && client.IsConnected)
                    {
                        PeerSnapshot local = CurrentLocal;
                        if (local == null)
                        {
                            Thread.Sleep(ExchangeIntervalMs);
                            continue;
                        }

                        writer.WriteLine(local.Serialize());

                        List<PeerSnapshot> received = new List<PeerSnapshot>();
                        while (true)
                        {
                            string line = reader.ReadLine();
                            if (line == null)
                                return true;
                            if (line.Length == 0)
                                break;

                            PeerSnapshot parsed = PeerSnapshot.Parse(line);
                            if (parsed != null)
                                received.Add(parsed);
                        }

                        ReplaceRemote(generation, received);
                        Thread.Sleep(ExchangeIntervalMs);
                    }
                }
            }
            catch (Exception ex)
            {
                SetError(generation, ex.Message);
            }
            finally
            {
                Untrack(client);
                DisposeQuiet(client);
                ReplaceRemote(generation, new List<PeerSnapshot>());
            }

            return true;
        }

        private void TryRunAsHub(int generation)
        {
            NamedPipeServerStream server;

            try
            {
                server = new NamedPipeServerStream(
                    CurrentPipeName,
                    PipeDirection.InOut,
                    MaxServerInstances,
                    PipeTransmissionMode.Byte,
                    PipeOptions.CurrentUserOnly);
            }
            catch (Exception ex)
            {
                SetError(generation, ex.Message);
                return;
            }

            Track(server);
            SetRole(generation, LinkRole.Hub);
            SetError(generation, string.Empty);

            try
            {
                server.WaitForConnection();
            }
            catch (Exception)
            {
                Untrack(server);
                DisposeQuiet(server);
                return;
            }

            try
            {
                ServeClient(generation, server);
            }
            finally
            {
                Untrack(server);
                DisposeQuiet(server);
            }
        }

        private void ServeClient(int generation, NamedPipeServerStream server)
        {
            ulong clientGuid = 0UL;

            try
            {
                using (StreamReader reader = new StreamReader(server, new UTF8Encoding(false), false, 1024, true))
                using (StreamWriter writer = new StreamWriter(server, new UTF8Encoding(false), 1024, true))
                {
                    writer.AutoFlush = true;

                    while (IsCurrent(generation) && server.IsConnected)
                    {
                        string line = reader.ReadLine();
                        if (line == null)
                            break;

                        PeerSnapshot snapshot = PeerSnapshot.Parse(line);
                        if (snapshot == null)
                            continue;

                        clientGuid = snapshot.Guid;
                        Absorb(generation, snapshot);

                        foreach (PeerSnapshot known in KnownExcept(clientGuid))
                            writer.WriteLine(known.Serialize());

                        writer.WriteLine();
                    }
                }
            }
            catch (Exception ex)
            {
                SetError(generation, ex.Message);
            }
            finally
            {
                if (clientGuid != 0UL)
                {
                    lock (_sync)
                    {
                        if (_generation == generation)
                            _remote.Remove(clientGuid);
                    }
                }

                try { server.Disconnect(); }
                catch (Exception) { }
            }
        }

        private static void DisposeQuiet(IDisposable disposable)
        {
            if (disposable == null)
                return;

            try { disposable.Dispose(); }
            catch (Exception) { }
        }
    }
}
