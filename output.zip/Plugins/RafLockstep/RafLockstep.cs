using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using Bots.Quest;
using Bots.Quest.QuestOrder;
using CommonBehaviors.Actions;
using CopilotBuddy.Buddy.Overlay;
using Styx.Common;
using Styx.Logic.Pathing;
using Styx.Helpers;
using Styx.Plugins.PluginClass;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using TreeSharp;
using WpfColors = System.Windows.Media.Colors;

namespace Styx.Bot.Plugins.Raf
{
    public class RafLockstep : HBPlugin
    {
        private const string LevelGrantEvent = "LEVEL_GRANT_PROPOSED";
        private const string SummonEvent = "CONFIRM_SUMMON";
        private const string PartyInviteEvent = "PARTY_INVITE_REQUEST";
        private const string GateHookLocation = "Taxi_Check";
        private const int OpenPulsesToResetBreaker = 8;

        private readonly PeerLink _link = new PeerLink();
        private readonly Stopwatch _holdTimer = new Stopwatch();

        private LuaEventHandlerDelegate _levelGrantHandler;
        private LuaEventHandlerDelegate _summonHandler;
        private LuaEventHandlerDelegate _partyInviteHandler;
        private RafOverlay _overlay;
        private bool _overlayPending;
        private bool _overlayFailed;
        private PeerSnapshot _recoveryTarget;
        private Composite _gate;
        private RafWindow _window;
        private RafSettings _settings;

        private string _gateReason = string.Empty;
        private string _loggedKey = string.Empty;
        private int _openPulses;
        private bool _failedOpen;
        private bool _eventsAttached;
        private bool _wantDetach;
        private bool _settingsBroken;

        public override string Name
        {
            get { return "RAF Lockstep"; }
        }

        public override string Author
        {
            get { return "Likon69"; }
        }

        public override Version Version
        {
            get { return new Version(1, 1, 0); }
        }

        public override bool WantButton
        {
            get { return true; }
        }

        public override string ButtonText
        {
            get { return "Settings"; }
        }

        public bool IsHolding { get; private set; }

        public string GateReason
        {
            get { return _gateReason; }
        }

        public LinkRole Role
        {
            get { return _link.Role; }
        }

        public string LinkError
        {
            get { return _link.LastError; }
        }

        public PeerSnapshot LocalSnapshot { get; private set; }

        public List<PeerSnapshot> GetPeers()
        {
            RafSettings settings = _settings;
            return _link.GetPeers(settings != null ? settings.PeerTimeoutMs : 3000);
        }

        public override void OnEnable()
        {
            try
            {
                InstallGate();
                _settings = RafSettings.Instance;
                _settingsBroken = false;
                _overlayFailed = false;
                _link.Start(_settings.PipeName);
                Log(WpfColors.LightGreen, "[{0}] {1} enabled.", Name, Version);
            }
            catch (Exception ex)
            {
                _settingsBroken = true;
                Logging.WriteException(ex);
                Log(WpfColors.Orange, "[{0}] failed to start, the plugin will stay idle.", Name);
            }
        }

        public override void OnDisable()
        {
            _wantDetach = _eventsAttached;
            RemoveGate();
            RemoveOverlay();
            _link.Stop();
            ReleaseHold(false);
            Log(WpfColors.Orange, "[{0}] disabled.", Name);
        }

        public override void Dispose()
        {
            RemoveGate();
            RemoveOverlay();
            _link.Stop();
            CloseWindow();
        }

        public override void OnButtonPress()
        {
            ShowWindow();
        }

        public override void Pulse()
        {
            try
            {
                if (_settingsBroken)
                    return;

                RafSettings settings = _settings ?? (_settings = RafSettings.Instance);

                if (_wantDetach)
                {
                    DetachEvents();
                    return;
                }

                if (!settings.Enabled || !StyxWoW.IsInGame || StyxWoW.Me == null)
                {
                    ReleaseHold(false);
                    return;
                }

                AttachEvents();

                PeerSnapshot local = BuildSnapshot(settings);
                LocalSnapshot = local;
                _link.Publish(local);

                List<PeerSnapshot> peers = _link.GetPeers(settings.PeerTimeoutMs);
                string key;
                string reason = EvaluateGate(local, peers, settings, out key);

                SyncOverlay(settings);

                if (reason == null)
                {
                    _recoveryTarget = null;
                    ReleaseHold(true);
                    return;
                }

                ApplyHold(reason, key, settings);
                Recover(local, settings);
            }
            catch (Exception ex)
            {
                Logging.WriteException(ex);
            }
        }

        private PeerSnapshot BuildSnapshot(RafSettings settings)
        {
            LocalPlayer me = StyxWoW.Me;

            QuestIntent intent;
            uint questId;
            ReadIntent(out intent, out questId);

            PeerSnapshot snapshot = new PeerSnapshot();
            snapshot.Name = me.Name;
            snapshot.Guid = me.Guid;
            snapshot.Level = me.Level;
            snapshot.Intent = intent;
            snapshot.QuestId = questId;
            snapshot.Holding = IsHolding;
            snapshot.InCombat = me.Combat;
            snapshot.Dead = me.IsDead || me.IsGhost;
            snapshot.MapId = me.MapId;
            snapshot.X = me.Location.X;
            snapshot.Y = me.Location.Y;
            snapshot.Z = me.Location.Z;
            snapshot.StampTicks = DateTime.UtcNow.Ticks;

            if (questId != 0)
            {
                snapshot.HasQuest = me.QuestLog.ContainsQuest(questId);
                snapshot.QuestCompleted = me.QuestLog.GetCompletedQuests().Contains(questId);
            }

            uint asked = 0;
            List<PeerSnapshot> peers = _link.GetPeers(settings.PeerTimeoutMs);
            for (int i = 0; i < peers.Count; i++)
            {
                if (peers[i].QuestId != 0)
                {
                    asked = peers[i].QuestId;
                    break;
                }
            }

            if (asked != 0)
            {
                snapshot.AboutQuestId = asked;
                snapshot.AboutInLog = me.QuestLog.ContainsQuest(asked);
                snapshot.AboutCompleted = me.QuestLog.GetCompletedQuests().Contains(asked);
            }

            return snapshot;
        }

        private static void ReadIntent(out QuestIntent intent, out uint questId)
        {
            intent = QuestIntent.None;
            questId = 0;

            QuestOrder order = QuestOrder.Instance ?? QuestState.Instance.Order;
            ForcedBehavior behavior = order != null ? order.CurrentBehavior : null;
            if (behavior == null)
                return;

            ForcedQuestTurnIn turnIn = behavior as ForcedQuestTurnIn;
            if (turnIn != null)
            {
                intent = QuestIntent.TurnIn;
                questId = turnIn.QuestId;
                return;
            }

            ForcedQuestPickUp pickUp = behavior as ForcedQuestPickUp;
            if (pickUp != null)
            {
                intent = QuestIntent.PickUp;
                questId = pickUp.QuestId;
                return;
            }

            ForcedQuestObjective objective = behavior as ForcedQuestObjective;
            if (objective != null && objective.Objective != null && objective.Objective.Quest != null)
            {
                intent = QuestIntent.Objective;
                questId = objective.Objective.Quest.Id;
                return;
            }

            ForcedMoveTo moveTo = behavior as ForcedMoveTo;
            if (moveTo != null && moveTo.QuestId != 0)
            {
                intent = QuestIntent.MoveTo;
                questId = moveTo.QuestId;
                return;
            }

            ForcedUseItem useItem = behavior as ForcedUseItem;
            if (useItem != null && useItem.QuestId != 0)
            {
                intent = QuestIntent.UseItem;
                questId = useItem.QuestId;
            }
        }

        private static PeerSnapshot Farthest;

        private static string EvaluateGate(PeerSnapshot local, List<PeerSnapshot> peers, RafSettings settings, out string key)
        {
            key = string.Empty;
            Farthest = null;

            if (local.Dead || local.InCombat)
                return null;

            if (peers.Count == 0)
                return null;

            for (int i = 0; i < peers.Count; i++)
            {
                PeerSnapshot peer = peers[i];

                if (peer.Dead)
                {
                    Farthest = peer;
                    key = "dead:" + peer.Name;
                    return peer.Name + " is dead";
                }

                float distance = local.DistanceTo(peer);
                if (distance > settings.LeashRange && ShouldYieldTo(local, peer))
                {
                    Farthest = peer;
                    key = "leash:" + peer.Name;
                    return string.Format(CultureInfo.InvariantCulture,
                        "{0} is {1:F0} yards away", peer.Name,
                        distance == float.MaxValue ? 0f : distance);
                }
            }

            if (!settings.LockstepQuests || local.Intent == QuestIntent.None)
                return null;

            for (int i = 0; i < peers.Count; i++)
            {
                PeerSnapshot peer = peers[i];

                if (peer.Intent == QuestIntent.None || peer.QuestId == local.QuestId)
                    continue;

                if (peer.AboutQuestId == local.QuestId)
                {
                    if (peer.AboutCompleted)
                        continue;

                    if (settings.ReleaseOnPeerCompleted && !peer.AboutInLog && !ShouldYieldTo(local, peer))
                        continue;

                    key = "quest:" + peer.Name + ":" + local.QuestId.ToString(CultureInfo.InvariantCulture);
                    return string.Format(CultureInfo.InvariantCulture,
                        "{0} has not done quest {1} yet", peer.Name, local.QuestId);
                }

                if (!ShouldYieldTo(local, peer))
                    continue;

                key = "desync:" + peer.Name + ":" + peer.QuestId.ToString(CultureInfo.InvariantCulture);
                return string.Format(CultureInfo.InvariantCulture,
                    "{0} is on quest {1}, we are on {2}", peer.Name, peer.QuestId, local.QuestId);
            }

            return null;
        }

        private static bool ShouldYieldTo(PeerSnapshot local, PeerSnapshot peer)
        {
            if (local.IsAdvancedOver(peer))
                return true;
            if (peer.IsAdvancedOver(local))
                return false;

            if (peer.AboutQuestId == local.QuestId && peer.AboutCompleted)
                return false;
            if (local.AboutQuestId == peer.QuestId && local.AboutCompleted)
                return true;

            return string.CompareOrdinal(local.Name, peer.Name) > 0;
        }

        private void ApplyHold(string reason, string key, RafSettings settings)
        {
            _openPulses = 0;

            if (!_holdTimer.IsRunning)
            {
                _holdTimer.Restart();
                _failedOpen = false;
            }

            if (settings.MaxHoldSeconds > 0 && _holdTimer.Elapsed.TotalSeconds > settings.MaxHoldSeconds)
            {
                if (!_failedOpen)
                {
                    _failedOpen = true;
                    Log(WpfColors.Orange, "[{0}] held {1}s on \"{2}\" - failing open so the run cannot deadlock.",
                        Name, settings.MaxHoldSeconds, reason);
                }

                IsHolding = false;
                _gateReason = reason + " (failed open)";
                return;
            }

            IsHolding = true;
            _gateReason = reason;

            if (_loggedKey != key)
            {
                _loggedKey = key;
                Log(WpfColors.Gold, "[{0}] holding: {1}.", Name, reason);
            }
        }

        private void ReleaseHold(bool announce)
        {
            if (IsHolding)
            {
                IsHolding = false;
                if (announce)
                    Log(WpfColors.LightGreen, "[{0}] gate open, resuming.", Name);
            }

            _gateReason = string.Empty;

            if (_holdTimer.IsRunning && ++_openPulses < OpenPulsesToResetBreaker)
                return;

            _loggedKey = string.Empty;
            _failedOpen = false;
            _holdTimer.Reset();
        }

        private void Recover(PeerSnapshot local, RafSettings settings)
        {
            _recoveryTarget = Farthest;

            if (!IsHolding || !settings.FollowWhenLost || _recoveryTarget == null || local == null)
                return;

            if (_recoveryTarget.MapId != local.MapId)
                return;

            float distance = local.DistanceTo(_recoveryTarget);
            if (distance == float.MaxValue)
                return;

            // FollowRange must never sit above LeashRange: if it did, the gate would hold
            // (freezing quest/combat logic) for every yard between the two thresholds
            // without the bot ever trying to close the gap on its own.
            // LeashRange/FollowRange are declared as double in RafSettings, hence the cast.
            float followThreshold = (float)Math.Min(settings.FollowRange, settings.LeashRange);
            if (distance <= followThreshold)
                return;

            Navigator.MoveTo(new WoWPoint(_recoveryTarget.X, _recoveryTarget.Y, _recoveryTarget.Z));
        }

        private void SyncOverlay(RafSettings settings)
        {
            if (!settings.ShowOverlay)
            {
                RemoveOverlay();
                return;
            }

            if (_overlay != null || _overlayPending || _overlayFailed)
                return;

            try
            {
                OverlayManager manager = StyxWoW.Overlay;
                _overlayPending = true;

                manager.Dispatcher.BeginInvoke(new System.Action(() =>
                {
                    try
                    {
                        RafOverlay overlay = new RafOverlay(this);
                        manager.AddUIComponent(overlay);
                        _overlay = overlay;
                        Log(WpfColors.LightGreen, "[{0}] overlay attached.", Name);
                    }
                    catch (Exception inner)
                    {
                        _overlayFailed = true;
                        Logging.WriteException(inner);
                        Log(WpfColors.Orange, "[{0}] overlay could not be created, continuing without it.", Name);
                    }
                    finally
                    {
                        _overlayPending = false;
                    }
                }));
            }
            catch (Exception ex)
            {
                _overlayPending = false;
                _overlayFailed = true;
                Logging.WriteException(ex);
            }
        }

        private void RemoveOverlay()
        {
            RafOverlay overlay = _overlay;
            _overlay = null;

            if (overlay == null)
                return;

            try
            {
                if (StyxWoW.IsOverlayActive)
                    StyxWoW.Overlay.RemoveUIComponent(overlay);
            }
            catch (Exception ex)
            {
                Logging.WriteException(ex);
            }
        }

        private void InstallGate()
        {
            if (_gate != null)
                return;

            _gate = new Decorator(ctx => IsHolding, new ActionAlwaysSucceed());
            TreeHooks.Instance.InsertHook(GateHookLocation, 0, _gate);
        }

        private void RemoveGate()
        {
            if (_gate == null)
                return;

            try
            {
                TreeHooks.Instance.RemoveHook(GateHookLocation, _gate);
            }
            catch (Exception ex)
            {
                Logging.WriteException(ex);
            }

            _gate = null;
        }

        private void AttachEvents()
        {
            if (_eventsAttached)
                return;

            _levelGrantHandler = OnLevelGrantProposed;
            _summonHandler = OnSummonProposed;
            _partyInviteHandler = OnPartyInvite;
            Lua.Events.AttachEvent(LevelGrantEvent, _levelGrantHandler);
            Lua.Events.AttachEvent(SummonEvent, _summonHandler);
            Lua.Events.AttachEvent(PartyInviteEvent, _partyInviteHandler);
            _eventsAttached = true;
        }

        private void DetachEvents()
        {
            _wantDetach = false;

            if (!_eventsAttached)
                return;

            try
            {
                Lua.Events.DetachEvent(LevelGrantEvent, _levelGrantHandler);
                Lua.Events.DetachEvent(SummonEvent, _summonHandler);
                Lua.Events.DetachEvent(PartyInviteEvent, _partyInviteHandler);
            }
            catch (Exception ex)
            {
                Logging.WriteException(ex);
            }

            _levelGrantHandler = null;
            _summonHandler = null;
            _partyInviteHandler = null;
            _eventsAttached = false;
        }

        private void OnLevelGrantProposed(object sender, LuaEventArgs e)
        {
            if (_settings == null || !_settings.AcceptLevelGrants)
                return;

            Log(WpfColors.LightGreen, "[{0}] level grant proposed, accepting.", Name);
            Lua.DoString("AcceptLevelGrant()");
        }

        private void OnSummonProposed(object sender, LuaEventArgs e)
        {
            if (_settings == null || !_settings.AcceptSummons)
                return;

            Log(WpfColors.LightGreen, "[{0}] summon offered, accepting.", Name);
            Lua.DoString("ConfirmSummon()");
        }

        private void OnPartyInvite(object sender, LuaEventArgs e)
        {
            if (_settings == null || !_settings.AcceptPartyInvites)
                return;

            Log(WpfColors.LightGreen, "[{0}] party invite received, accepting.", Name);
            Lua.DoString("AcceptGroup()");
        }

        private void ShowWindow()
        {
            System.Windows.Application application = System.Windows.Application.Current;
            if (application != null && !application.Dispatcher.CheckAccess())
            {
                application.Dispatcher.BeginInvoke(new System.Action(ShowWindow));
                return;
            }

            try
            {
                if (_window == null)
                {
                    _window = new RafWindow(this);
                    _window.Closed += (s, e) => _window = null;
                }

                _window.Show();
                _window.Activate();
            }
            catch (Exception ex)
            {
                Logging.WriteException(ex);
            }
        }

        private void CloseWindow()
        {
            RafWindow window = _window;
            if (window == null)
                return;

            System.Windows.Application application = System.Windows.Application.Current;
            if (application != null && !application.Dispatcher.CheckAccess())
            {
                application.Dispatcher.BeginInvoke(new System.Action(CloseWindow));
                return;
            }

            try
            {
                window.Close();
            }
            catch (Exception ex)
            {
                Logging.WriteException(ex);
            }

            _window = null;
        }

        private static void Log(System.Windows.Media.Color color, string format, params object[] args)
        {
            Logging.Write(color, format, args);
        }
    }
}
