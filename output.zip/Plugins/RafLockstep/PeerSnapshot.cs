using System;
using System.Globalization;
using System.Text;

namespace Styx.Bot.Plugins.Raf
{
    public enum QuestIntent
    {
        None = 0,
        PickUp = 1,
        TurnIn = 2,
        Objective = 3,
        MoveTo = 4,
        UseItem = 5
    }

    public class PeerSnapshot
    {
        public string Name { get; set; }
        public ulong Guid { get; set; }
        public int Level { get; set; }
        public QuestIntent Intent { get; set; }
        public uint QuestId { get; set; }
        public bool HasQuest { get; set; }
        public bool QuestCompleted { get; set; }
        public bool Holding { get; set; }
        public bool InCombat { get; set; }
        public bool Dead { get; set; }
        public uint MapId { get; set; }
        public float X { get; set; }
        public float Y { get; set; }
        public float Z { get; set; }
        public uint AboutQuestId { get; set; }
        public bool AboutInLog { get; set; }
        public bool AboutCompleted { get; set; }
        public long StampTicks { get; set; }

        public PeerSnapshot()
        {
            Name = string.Empty;
        }

        public bool IsStale(int timeoutMs)
        {
            if (timeoutMs <= 0)
                return false;

            long age = DateTime.UtcNow.Ticks - StampTicks;
            return age < 0 || age > TimeSpan.TicksPerMillisecond * timeoutMs;
        }

        public bool IsAdvancedOver(PeerSnapshot other)
        {
            if (other == null)
                return false;
            if (QuestId != other.QuestId)
                return false;
            return Intent == QuestIntent.TurnIn && other.Intent == QuestIntent.PickUp;
        }

        public float DistanceTo(PeerSnapshot other)
        {
            if (other == null || other.MapId != MapId)
                return float.MaxValue;

            float dx = X - other.X;
            float dy = Y - other.Y;
            float dz = Z - other.Z;
            return (float)Math.Sqrt(dx * dx + dy * dy + dz * dz);
        }

        public string Describe()
        {
            if (Intent == QuestIntent.None)
                return "idle";
            return string.Format(CultureInfo.InvariantCulture, "{0} {1}", Intent, QuestId);
        }

        public string Serialize()
        {
            StringBuilder builder = new StringBuilder();
            builder.Append("n=").Append(Encode(Name));
            builder.Append(";g=").Append(Guid.ToString(CultureInfo.InvariantCulture));
            builder.Append(";lv=").Append(Level.ToString(CultureInfo.InvariantCulture));
            builder.Append(";it=").Append(((int)Intent).ToString(CultureInfo.InvariantCulture));
            builder.Append(";q=").Append(QuestId.ToString(CultureInfo.InvariantCulture));
            builder.Append(";hq=").Append(HasQuest ? '1' : '0');
            builder.Append(";qc=").Append(QuestCompleted ? '1' : '0');
            builder.Append(";h=").Append(Holding ? '1' : '0');
            builder.Append(";c=").Append(InCombat ? '1' : '0');
            builder.Append(";d=").Append(Dead ? '1' : '0');
            builder.Append(";m=").Append(MapId.ToString(CultureInfo.InvariantCulture));
            builder.Append(";x=").Append(X.ToString("R", CultureInfo.InvariantCulture));
            builder.Append(";y=").Append(Y.ToString("R", CultureInfo.InvariantCulture));
            builder.Append(";z=").Append(Z.ToString("R", CultureInfo.InvariantCulture));
            builder.Append(";aq=").Append(AboutQuestId.ToString(CultureInfo.InvariantCulture));
            builder.Append(";al=").Append(AboutInLog ? '1' : '0');
            builder.Append(";ac=").Append(AboutCompleted ? '1' : '0');
            builder.Append(";t=").Append(StampTicks.ToString(CultureInfo.InvariantCulture));
            return builder.ToString();
        }

        public static PeerSnapshot Parse(string line)
        {
            if (string.IsNullOrWhiteSpace(line))
                return null;

            PeerSnapshot snapshot = new PeerSnapshot();
            string[] fields = line.Split(';');

            foreach (string field in fields)
            {
                int split = field.IndexOf('=');
                if (split <= 0)
                    continue;

                string key = field.Substring(0, split);
                string value = field.Substring(split + 1);

                switch (key)
                {
                    case "n": snapshot.Name = Decode(value); break;
                    case "g": snapshot.Guid = ParseULong(value); break;
                    case "lv": snapshot.Level = ParseInt(value); break;
                    case "it": snapshot.Intent = (QuestIntent)ParseInt(value); break;
                    case "q": snapshot.QuestId = ParseUInt(value); break;
                    case "hq": snapshot.HasQuest = value == "1"; break;
                    case "qc": snapshot.QuestCompleted = value == "1"; break;
                    case "h": snapshot.Holding = value == "1"; break;
                    case "c": snapshot.InCombat = value == "1"; break;
                    case "d": snapshot.Dead = value == "1"; break;
                    case "m": snapshot.MapId = ParseUInt(value); break;
                    case "x": snapshot.X = ParseFloat(value); break;
                    case "y": snapshot.Y = ParseFloat(value); break;
                    case "z": snapshot.Z = ParseFloat(value); break;
                    case "aq": snapshot.AboutQuestId = ParseUInt(value); break;
                    case "al": snapshot.AboutInLog = value == "1"; break;
                    case "ac": snapshot.AboutCompleted = value == "1"; break;
                    case "t": snapshot.StampTicks = ParseLong(value); break;
                }
            }

            return snapshot.Guid == 0UL ? null : snapshot;
        }

        private static string Encode(string value)
        {
            if (string.IsNullOrEmpty(value))
                return string.Empty;
            return value.Replace("%", "%25").Replace(";", "%3B").Replace("=", "%3D")
                        .Replace("\r", "%0D").Replace("\n", "%0A");
        }

        private static string Decode(string value)
        {
            if (string.IsNullOrEmpty(value))
                return string.Empty;
            return value.Replace("%0A", "\n").Replace("%0D", "\r")
                        .Replace("%3D", "=").Replace("%3B", ";").Replace("%25", "%");
        }

        private static int ParseInt(string value)
        {
            int result;
            return int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out result) ? result : 0;
        }

        private static uint ParseUInt(string value)
        {
            uint result;
            return uint.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out result) ? result : 0u;
        }

        private static float ParseFloat(string value)
        {
            float result;
            return float.TryParse(value, NumberStyles.Float, CultureInfo.InvariantCulture, out result) ? result : 0f;
        }

        private static ulong ParseULong(string value)
        {
            ulong result;
            return ulong.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out result) ? result : 0UL;
        }

        private static long ParseLong(string value)
        {
            long result;
            return long.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out result) ? result : 0L;
        }
    }
}
