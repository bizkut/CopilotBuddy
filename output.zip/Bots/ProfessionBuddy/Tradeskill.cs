﻿//!CompilerOption:Optimize:On
// Copyright Highvoltz 2012

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using Styx;
using Styx.Helpers;
using Styx.Logic;
using Styx.Logic.BehaviorTree;
using Styx.Logic.Combat;
using Styx.Patchables;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWCache;
using Styx.WoWInternals.WoWObjects;

namespace HighVoltz
{

    #region TradeSkill

    public class TradeSkill
    {
        private const uint SkillLineAbilityFieldNum = 14;
        private const uint SkillLineAbilityEntrySize = SkillLineAbilityFieldNum*4; // number of fields * sizeof int

        public static readonly List<SkillLine> SupportedSkills = new List<SkillLine>
                                                                     {
                                                                         SkillLine.Alchemy,
                                                                         SkillLine.Blacksmithing,
                                                                         SkillLine.Cooking,
                                                                         SkillLine.Enchanting,
                                                                         SkillLine.Engineering,
                                                                         SkillLine.FirstAid,
                                                                         SkillLine.Inscription,
                                                                         SkillLine.Jewelcrafting,
                                                                         SkillLine.Leatherworking,
                                                                         SkillLine.Mining,
                                                                         // smelting
                                                                         SkillLine.Tailoring,
                                                                     };

        private Dictionary<uint, IngredientSubClass> _ingredients;
        private List<Tool> _tools;

        static TradeSkill()
        {
            // WotLK 3.3.5a — no pattern scan needed; HasSpell uses Lua
        }

        private TradeSkill(WoWSkill skill)
        {
            WoWSkill = skill;
            Recipes = new Dictionary<uint, Recipe>();
        }

        public WoWSkill WoWSkill { get; internal set; }

        /// <summary>
        /// Amount of Bonus the player has to the Tradeskill 
        /// </summary>
        public uint Bonus
        {
            get { return WoWSkill.Bonus; }
        }

        /// <summary>
        /// Tradeskill level
        /// </summary>
        public int Level
        {
            get { return WoWSkill.CurrentValue; }
        }

        /// <summary>
        /// Maximum level of the Tradeskill 
        /// </summary>
        public int MaxLevel
        {
            get { return WoWSkill.MaxValue; }
        }

        /// <summary>
        /// Name of the Tradeskill
        /// </summary>
        public string Name
        {
            get { return WoWSkill.Name; }
        }

        public SkillLine SkillLine
        {
            get { return (SkillLine) WoWSkill.Id; }
        }

        /// <summary>
        /// List of ingredients 
        /// </summary>
        public Dictionary<uint, IngredientSubClass> Ingredients
        {
            get
            {
                if (_ingredients == null)
                {
                    InitIngredientList();
                }
                return _ingredients;
            }
        }

        /// <summary>
        /// List of Tools
        /// </summary>
        public List<Tool> Tools
        {
            get
            {
                if (_tools == null)
                {
                    InitToolList();
                }
                return _tools;
            }
        }

        /// <summary>
        /// List of known recipes
        /// </summary>
        public Dictionary<uint, Recipe> KnownRecipes
        {
            get
            {
                return Recipes.Where(r => r.Value.HasRecipe)
                    .ToDictionary(k => k.Key, v => v.Value);
            }
        }

        /// <summary>
        /// List of all recipes
        /// </summary>
        public Dictionary<uint, Recipe> Recipes { get; private set; }

        /// <summary>
        /// number of Recipes
        /// </summary>
        public int RecipeCount
        {
            get { return KnownRecipes.Count; }
        }

        private List<SkillLineAbilityEntry> GetSkillLineAbilityEntries()
        {
            var abilityList = new List<SkillLineAbilityEntry>();
            int targetSkillId = (int)SkillLine;

            var table = StyxWoW.Db[ClientDb.SkillLineAbility];
            if (table == null)
            {
                Professionbuddy.Log("SkillLineAbility DBC table is NULL (enum={0})", (int)ClientDb.SkillLineAbility);
                return abilityList;
            }

            uint min = (uint)table.MinIndex;
            uint max = (uint)table.MaxIndex;
            Professionbuddy.Debug("SkillLineAbility: rows={0} min={1} max={2} target={3}", table.NumRows, min, max, targetSkillId);

            int nullRows = 0;
            int totalRows = 0;
            for (uint i = min; i <= max; i++)
            {
                var row = table.GetRow(i);
                if (row == null)
                {
                    nullRows++;
                    continue;
                }
                totalRows++;
                var entry = row.GetStruct<SkillLineAbilityEntry>();
                if ((int)entry.SkillLine == targetSkillId)
                    abilityList.Add(entry);
            }
            Professionbuddy.Debug("SkillLineAbility scan: {0} valid rows, {1} null, {2} matched skill {3}",
                totalRows, nullRows, abilityList.Count, SkillLine);
            return abilityList;
        }

        private void AddRecipe(Recipe recipe)
        {
            if (!Recipes.ContainsKey(recipe.SpellId))
            {
                Recipes.Add(recipe.SpellId, recipe);
                recipe.InitIngredients();
                recipe.InitTools();
            }
        }

        private void InitIngredientList()
        {
            _ingredients = new Dictionary<uint, IngredientSubClass>();
            foreach (var recipePair in KnownRecipes)
            {
                recipePair.Value.InitIngredients();
            }
        }

        internal void InitToolList()
        {
            _tools = new List<Tool>();
            foreach (var recipePair in KnownRecipes)
            {
                recipePair.Value.InitTools();
            }
        }

        /// <summary>
        /// Syncs Ingredient and Tool list with Bags
        /// </summary>
        public void PulseBags()
        {
            if (!TreeRoot.IsRunning)
                ObjectManager.Update();
            foreach (var ingredPair in Ingredients)
            {
                ingredPair.Value.UpdateInBagsCount();
            }
            foreach (Tool tool in Tools)
            {
                tool.UpdateToolStatus();
            }
        }

        // syncs the TradeSkill, updating Skill level,recipe dificulty and adding new recipes that arent in list
        public void PulseSkill()
        {
            Update();
        }

        /// <summary>
        /// Updates the skill level, recipe difficulty and adds new recipes.
        /// </summary>
        public void Update()
        {
            if (!ObjectManager.IsInGame)
                return;
            // if HB is not running then we should maybe pulse objectmanger for item counts
            if (!TreeRoot.IsRunning)
                ObjectManager.Update();

            WoWSkill = ObjectManager.Me.GetSkill(SkillLine);
            Dictionary<uint, Recipe> oldList = KnownRecipes;
            // cycle through entire recipe list and check update the 'HasRecipe' property
            foreach (var recipe in Recipes)
            {
                recipe.Value.Update();
            }
            IEnumerable<KeyValuePair<uint, Recipe>> newRecipies = KnownRecipes.Except(oldList);
            foreach (var kv in newRecipies)
            {
                Professionbuddy.Log("Leaned a new recipe {0}", kv.Value.Name);
                using (new FrameLock())
                {
                    kv.Value.UpdateHeader();
                }
            }
            PulseBags();
        }

        /// <summary>
        /// Returns a list of recipes from selected skill
        /// </summary>
        /// <param name="skillLine"></param>
        /// <returns></returns>
        public static TradeSkill GetTradeSkill(SkillLine skillLine)
        {
            if (!ObjectManager.IsInGame)
                throw new InvalidOperationException("Must Be in game to call GetTradeSkill()");
            if (skillLine == 0 || !SupportedSkills.Contains(skillLine))
                throw new InvalidOperationException(String.Format("The tradekill {0} can not be loaded", skillLine));
            // if HB is not running then we need to pulse objectmanger for item counts
            if (!TreeRoot.IsRunning)
                ObjectManager.Update();
            //Stopwatch sw = new Stopwatch();
            TradeSkill tradeSkill = null;
            try
            {
                //using (new FrameLock())
                //{
                WoWSkill wowSkill = ObjectManager.Me.GetSkill(skillLine);
                // sw.Start();
                tradeSkill = new TradeSkill(wowSkill);

                LoadKnownRecipesForSkill(skillLine);

                List<SkillLineAbilityEntry> entries = tradeSkill.GetSkillLineAbilityEntries();
                int filtered = 0;
                foreach (SkillLineAbilityEntry entry in entries)
                {
                    if (entry.NextSpellId == 0 && entry.GreySkillLevel > 0)
                    {
                        var recipe = new Recipe(tradeSkill, entry);
                        recipe.UpdateHeader();
                        tradeSkill.AddRecipe(recipe);
                    }
                    else
                    {
                        filtered++;
                    }
                }
                Professionbuddy.Log("{0}: {1} entries, {2} filtered, {3} recipes loaded",
                    skillLine, entries.Count, filtered, tradeSkill.Recipes.Count);
            }
            catch (Exception ex)
            {
                Logging.WriteException(ex);
            }
            //Logging.Write("it took {0} ms to load {1}", sw.ElapsedMilliseconds, skillLine);
            return tradeSkill;
        }

        private static HashSet<int> _knownSpellIds;

        internal static void RefreshKnownSpells()
        {
            _knownSpellIds = new HashSet<int>();
        }

        internal static void LoadKnownRecipesForSkill(SkillLine skillLine)
        {
            string castName = skillLine.ToString();
            if (skillLine == SkillLine.FirstAid) castName = "First Aid";
            string lua =
                "CastSpellByName('" + castName + "') " +
                "local ids='' " +
                "local n=GetNumTradeSkills() or 0 " +
                "for i=1,n do " +
                "  local _,t=GetTradeSkillInfo(i) " +
                "  if t~='header' then " +
                "    local l=GetTradeSkillRecipeLink(i) " +
                "    if l then local id=l:match('enchant:(%d+)') if id then ids=ids..id..':' end end " +
                "  end " +
                "end " +
                "CloseTradeSkill() " +
                "return ids";
            var ret = Lua.GetReturnValues(lua);
            int added = 0;
            if (ret.Count > 0 && !string.IsNullOrEmpty(ret[0]))
            {
                foreach (var s in ret[0].Split(new[]{':'}, StringSplitOptions.RemoveEmptyEntries))
                {
                    if (int.TryParse(s, out int id))
                    {
                        _knownSpellIds.Add(id);
                        added++;
                    }
                }
            }
            Professionbuddy.Log("LoadKnownRecipesForSkill({0}): {1} known recipes", skillLine, added);
        }

        public static bool HasSpell(uint spellId)
        {
            if (_knownSpellIds == null) RefreshKnownSpells();
            return _knownSpellIds.Contains((int)spellId);
        }
    }

    #endregion

    #region Recipe

    public class Recipe
    {
        #region RecipeDifficulty enum

        public enum RecipeDifficulty
        {
            Optimal,
            Medium,
            Easy,
            Trivial
        }

        #endregion

        private readonly TradeSkill _parent;
        private uint? _craftedItemID;
        private string _header;
        private List<Ingredient> _ingredients;
        private string _name;
        private List<Tool> _tools;

        internal Recipe(TradeSkill parent, SkillLineAbilityEntry skillLineAbilityEntry)
        {
            _parent = parent;
            SpellId = skillLineAbilityEntry.SpellId;
            OrangeSkillLevel = skillLineAbilityEntry.OrangeSkillLevel;
            YellowSkillLevel = skillLineAbilityEntry.YellowSkillLevel;
            GreenSkillLevel = (skillLineAbilityEntry.YellowSkillLevel + skillLineAbilityEntry.GreySkillLevel)/2;
            GreySkillLevel = skillLineAbilityEntry.GreySkillLevel;
            OptimalSkillups = skillLineAbilityEntry.SkillPointsEarned;
            Skill = skillLineAbilityEntry.SkillLine;
            HasRecipe = TradeSkill.HasSpell(SpellId);
        }

        /// <summary>
        /// Returns the color that represents the recipes difficulty
        /// </summary>
        public Color Color
        {
            get
            {
                switch (Difficulty)
                {
                    case RecipeDifficulty.Optimal:
                        return Color.DarkOrange;
                    case RecipeDifficulty.Medium:
                        return Color.Yellow;
                    case RecipeDifficulty.Easy:
                        return Color.Lime;
                    default:
                        return Color.Gray;
                }
            }
        }

        /// <summary>
        /// The Number of times recipe can be crafted with current mats in bags using internal Ingredient list.
        /// </summary>
        public uint CanRepeatNum
        {
            get
            {
                uint repeat = uint.MaxValue;
                foreach (Ingredient ingred in Ingredients)
                {
                    var cnt = (uint) Math.Floor(ingred.InBagItemCount/(double) ingred.Required);
                    if (repeat > cnt)
                    {
                        repeat = cnt;
                    }
                }
                return repeat;
            }
        }

        /// <summary>
        /// The Number of times recipe can be crafted with current mats in bags. Checks directly with ObjectManager
        /// </summary>
        public uint CanRepeatNum2
        {
            get
            {
                uint repeat = uint.MaxValue;
                foreach (Ingredient ingred in Ingredients)
                {
                    var cnt = (uint) Math.Floor(Ingredient.GetInBagItemCount(ingred.ID)/(double) ingred.Required);
                    if (repeat > cnt)
                    {
                        repeat = cnt;
                    }
                }
                return repeat;
            }
        }

        /// <summary>
        /// Returns ID of the item the recipe makes
        /// </summary>
        public uint CraftedItemID
        {
            get
            {
                if (_craftedItemID.HasValue)
                    return _craftedItemID.Value;
                _craftedItemID = GetCraftedItemID();
                return (_craftedItemID.HasValue) ? _craftedItemID.Value : 0;
            }
        }

        public int DisplayOrder { get; private set; }

        /// <summary>
        /// Returns the difficulty of the Recipe
        /// </summary>
        public RecipeDifficulty Difficulty
        {
            get
            {
                int level = _parent.WoWSkill.CurrentValue;
                if (level < YellowSkillLevel)
                    return RecipeDifficulty.Optimal;
                if (level < GreenSkillLevel)
                    return RecipeDifficulty.Medium;
                if (level < GreySkillLevel)
                    return RecipeDifficulty.Easy;
                return RecipeDifficulty.Trivial;
            }
        }

        public bool HasRecipe { get; set; }

        // grab name from dbc

        public int GreySkillLevel { get; private set; }

        public int GreenSkillLevel { get; private set; }

        /// <summary>
        /// Name of header this recipe belongs to
        /// </summary>
        public string Header
        {
            get
            {
                if (_header == null || string.IsNullOrEmpty(_header))
                {
                    using (new FrameLock())
                    {
                        foreach (var recipe in _parent.KnownRecipes)
                        {
                            UpdateHeader();
                        }
                    }
                }
                return _header;
            }
        }

        /// <summary>
        /// List of ingredients required for the recipe
        /// </summary>
        public ReadOnlyCollection<Ingredient> Ingredients
        {
            get
            {
                if (_ingredients == null)
                    InitIngredients();
                if (_ingredients != null)
                    return _ingredients.AsReadOnly();
                return null;
            }
        }

        /// <summary>
        /// Name of the Recipe
        /// </summary>
        public string Name
        {
            get { return _name ?? (_name = GetName()); }
        }

        public int OrangeSkillLevel { get; private set; }

        /// <summary>
        /// Number of skillups earned when recipe difficulty is orange (optimal)
        /// </summary>
        public int OptimalSkillups { get; private set; }

        public uint SpellId { get; private set; }

        /// <summary>
        /// The Skill this recipe is from
        /// </summary>
        public SkillLine Skill { get; private set; }

        /// <summary>
        /// Number of Skillup this recipe will grant when crafted using current tradeskill level
        /// </summary>
        public int Skillups
        {
            get
            {
                switch (Difficulty)
                {
                    case RecipeDifficulty.Optimal:
                        return OptimalSkillups;
                    case RecipeDifficulty.Medium:
                    case RecipeDifficulty.Easy:
                        return 1;
                    default:
                        return 0;
                }
            }
        }

        /// <summary>
        /// returns the spell that's attached to the recipe
        /// </summary>
        public WoWSpell Spell
        {
            get { return WoWSpell.FromId((int) SpellId); }
        }

        public ReadOnlyCollection<Tool> Tools
        {
            get
            {
                if (_tools == null)
                    InitTools();
                if (_tools != null)
                    return _tools.AsReadOnly();
                return null;
            }
        }

        public int YellowSkillLevel { get; private set; }

        private uint? GetCraftedItemID()
        {
            if (Spell != null && Spell.SpellEffect1 != null)
            {
                return Spell.SpellEffect1.ItemType;
            }
            return null;
        }

        internal void InitIngredients()
        {
            // instantizing ingredients in here and doing a null check to prevent recursion from Trade.Ingredients() 
            if (_ingredients != null)
                return;
            _ingredients = new List<Ingredient>();
            var spell = Spell;
            if (spell == null)
                return;
            // WotLK 3.3.5a: reagents are embedded directly in Spell.dbc (monolithic)
            var info = spell.InternalInfo;
            if (info.Reagent == null)
                return;
            for (int i = 0; i < info.Reagent.Length; i++)
            {
                if (info.Reagent[i] != 0)
                    _ingredients.Add(new Ingredient((uint)info.Reagent[i], info.ReagentCount[i], _parent.Ingredients));
            }
        }

        public void UpdateHeader()
        {
            if (!string.IsNullOrEmpty(_header))
                return;
            WoWDb.DbTable dbTable;
            WoWDb.Row dbRow;
            if (CraftedItemID == 0)
            {
                dbTable = StyxWoW.Db[ClientDb.SkillLine];
                dbRow = dbTable?.GetRow((uint) Skill);
                if (dbRow == null) return;
                // WotLK 3.3.5a: displayName_lang starts at field 3 (16 locale slots)
                // Scan locale fields to find the first valid string pointer
                for (uint li = 3; li < 19 && string.IsNullOrEmpty(_header); li++)
                {
                    var namePtr = dbRow.GetField<uint>(li);
                    if (namePtr != 0)
                        _header = ObjectManager.Wow.Read<string>(namePtr);
                }
            }
            else
            {
                // we need to iterate through ClientDb.ItemSubClass till we find matching
                WoWCache.InfoBlock cache = StyxWoW.Cache[CacheDb.Item].GetInfoBlockById(CraftedItemID);

                if (cache != null)
                {
                    dbTable = StyxWoW.Db[ClientDb.ItemSubClass];
                    if (dbTable == null) return;
                    for (int i = dbTable.MinIndex; i <= dbTable.MaxIndex; i++)
                    {
                        dbRow = dbTable.GetRow((uint) i);
                        if (dbRow == null) continue;
                        var iSubClass1 = dbRow.GetField<int>(1);
                        var iSubClass2 = dbRow.GetField<int>(2);
                        if (iSubClass1 == cache.Item.ClassId && iSubClass2 == cache.Item.SubClassId)
                        {
                            // WotLK 3.3.5a: displayName_lang starts at field 11 (16 locale slots)
                            for (uint li = 11; li < 27 && string.IsNullOrEmpty(_header); li++)
                            {
                                var stringPtr = dbRow.GetField<uint>(li);
                                if (stringPtr != 0)
                                    _header = ObjectManager.Wow.Read<string>(stringPtr);
                            }
                            break;
                        }
                    }
                }
            }
        }

        private string GetName()
        {
            string name = SpellDb.GetSpellName((int)SpellId);
            return string.IsNullOrEmpty(name) ? null : name;
        }

        internal void InitTools()
        {
            // instantizing tools in here and doing a null check to prevent recursion from Trade.Tools() 
            if (_tools != null)
                return;
            _tools = new List<Tool>();
            var wowSpell = Spell;
            if (wowSpell == null) return;
            // WotLK 3.3.5a: tool data is embedded directly in monolithic SpellEntry
            var spell = wowSpell.InternalInfo;

            // Anvils, forge, etc (SpellFocusObject)
            if (spell.RequiresSpellFocus != 0)
            {
                _tools.Add(GetTool(spell.RequiresSpellFocus, Tool.ToolType.SpellFocus));
            }

            // AreaGroup requirement
            if (spell.AreaGroupId > 0)
            {
                var t = StyxWoW.Db[ClientDb.AreaGroup];
                var areaGroupDbRow = t?.GetRow((uint)spell.AreaGroupId);
                var areaTableIndex = areaGroupDbRow?.GetField<uint>(1) ?? 0;
                if (areaTableIndex != 0)
                {
                    _tools.Add(GetTool(areaTableIndex, Tool.ToolType.AreaTable));
                }
            }

            // Totem items (e.g. Runed Copper Rod for enchanting)
            for (int i = 0; i < 2; i++)
            {
                if (spell.Totem[i] != 0)
                {
                    _tools.Add(GetTool(spell.Totem[i], Tool.ToolType.Item));
                    break;
                }
            }

            // TotemCategory (Blacksmith hammer, mining pick, etc)
            for (int i = 0; i < 2; i++)
            {
                if (spell.TotemCategory[i] != 0)
                {
                    _tools.Add(GetTool(spell.TotemCategory[i], Tool.ToolType.Totem));
                    break;
                }
            }
        }

        // this basically checks if the master tool list already contains this tool and 
        // returns that tool if it does, otherwise it adds the tool to the master Tool list
        // and returns it.
        private Tool GetTool(uint index, Tool.ToolType toolType)
        {
            var newTool = new Tool(index, toolType);
            Tool tool = _parent.Tools.Find(a => a.Equals(newTool));
            if (tool == null)
            {
                tool = newTool;
                _parent.Tools.Add(tool);
            }
            return tool;
        }

        public void Update()
        {
            HasRecipe = TradeSkill.HasSpell(SpellId);
        }


    }

    #endregion

    #region IngredientSubClass

    // This class is used in a dictionary in the TradeSkill class and the purpose is to 
    // keep track of the number of ingredients in players bag,updated via Pulse().
    // this saves cpu cycles because it doesnt need to iterate through all the recipes.
    // Also this saves memory usage because each ingredient name gets loaded only once per ingredient.

    // someone give this a good name, kthz
    public class IngredientSubClass
    {
        private static readonly object NameLockObject = new object();
        internal Ingredient Parent;
        private string _name;

        internal IngredientSubClass(Ingredient parent, uint inBagCount)
        {
            Parent = parent;
            InBagsCount = inBagCount;
        }

        public string Name
        {
            get
            {
                lock (NameLockObject)
                {
                    return _name ?? (_name = GetName());
                }
            }
        }

        /// <summary>
        /// number of ingredients in players bags
        /// </summary>
        public uint InBagsCount { get; internal set; }

        private string GetName()
        {
            string name = Util.GetItemCacheName(Parent.ID);
            if (name == null)
            {
                // ok so it couldn't find the item in cache. since we're going to need to force a load
                // might as well do a framelock and try load all the items. 
                IEnumerable<uint> ids = Parent.MasterList.Keys.Where(id => id != Parent.ID);

                using (new FrameLock())
                {
                    foreach (uint id in ids)
                    {
                        name = Util.GetItemCacheName(id);
                    }
                }
            }
            return name;
        }

        /// <summary>
        /// updates the InBagsCount
        /// </summary>
        internal void UpdateInBagsCount()
        {
            InBagsCount = Ingredient.GetInBagItemCount(Parent.ID);
        }
    }

    #endregion

    #region Ingredient

    public class Ingredient
    {
        // someone give this a good name, kthz
        private readonly IngredientSubClass _subclass;
        // list where every ingredient is stored, used to save memory usage,
        // this points to the one initilized in a TradeSkill instance
        internal Dictionary<uint, IngredientSubClass> MasterList;

        internal Ingredient(uint id, uint requiredNum, Dictionary<uint, IngredientSubClass> masterList)
        {
            ID = id;
            Required = requiredNum;
            MasterList = masterList;
            if (masterList.ContainsKey(id))
            {
                _subclass = masterList[id];
            }
            else
            {
                _subclass = new IngredientSubClass(this, GetInBagItemCount(id));
                masterList.Add(id, _subclass);
            }
        }

        /// <summary>
        /// Name of the Reagent
        /// </summary>
        public string Name
        {
            get { return _subclass.Name; }
        }

        /// <summary>
        /// The required number of this reagent needed
        /// </summary>
        public uint Required { get; private set; }

        public uint ID { get; private set; }

        /// <summary>
        /// Number of this Reagent in players possession
        /// </summary>
        public uint InBagItemCount
        {
            get { return _subclass.InBagsCount; }
        }

        public static uint GetInBagItemCount(uint id)
        {
            try
            {
                return
                    (uint)
                    ObjectManager.Me.BagItems.Sum(i => i != null && i.IsValid && i.Entry == id ? i.StackCount : 0);
            }
            catch (Exception ex)
            {
                Logging.WriteException(ex);
                return 0;
            }
        }
    }

    #endregion

    #region Tool

    public class Tool
    {
        private readonly uint _index; // index to some DBC, depends on type
        private readonly ToolType _toolType;
        private string _name;

        internal Tool(uint index, ToolType toolType)
        {
            _index = index;
            _toolType = toolType;
            UpdateToolStatus();
            ID = toolType == ToolType.Item ? index : 0;
        }

        public uint ID { get; private set; }

        /// <summary>
        /// returns true if tool is in players bags
        /// </summary>
        public bool HasTool { get; internal set; }

        /// <summary>
        /// Name of the tool
        /// </summary>
        public string Name
        {
            get { return _name ?? (_name = GetName()); }
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
                return false;
            if (obj is Tool)
            {
                var t = obj as Tool;
                return _index == t._index && _toolType == t._toolType;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return (int) _index + (int) _toolType*100000;
        }

        private string GetName()
        {
            string name = null;
            WoWDb.DbTable t;
            WoWDb.Row r;
            switch (_toolType)
            {
                case ToolType.SpellFocus:
                    t = StyxWoW.Db[ClientDb.SpellFocusObject];
                    r = t?.GetRow(_index);
                    if (r == null) break;
                    // WotLK: Name_lang starts at field 1 (16 locale slots)
                    for (uint li = 1; li < 17 && name == null; li++)
                    {
                        var ptr = r.GetField<uint>(li);
                        if (ptr != 0)
                            name = ObjectManager.Wow.Read<string>(ptr);
                    }
                    break;
                case ToolType.AreaTable:
                    t = StyxWoW.Db[ClientDb.AreaTable];
                    r = t?.GetRow(_index);
                    if (r == null) break;
                    // WotLK: AreaName_lang starts at field 11 (16 locale slots)
                    for (uint li = 11; li < 27 && name == null; li++)
                    {
                        var ptr = r.GetField<uint>(li);
                        if (ptr != 0)
                            name = ObjectManager.Wow.Read<string>(ptr);
                    }
                    break;
                case ToolType.Item:
                    name = Util.GetItemCacheName(_index);
                    break;
                case ToolType.Totem:
                    t = StyxWoW.Db[ClientDb.TotemCategory];
                    r = t?.GetRow(_index);
                    if (r == null) break;
                    // WotLK: Name_lang starts at field 1 (16 locale slots)
                    for (uint li = 1; li < 17 && name == null; li++)
                    {
                        var ptr = r.GetField<uint>(li);
                        if (ptr != 0)
                            name = ObjectManager.Wow.Read<string>(ptr);
                    }
                    break;
            }
            return name;
        }

        internal void UpdateToolStatus()
        {
            switch (_toolType)
            {
                case ToolType.SpellFocus:
                case ToolType.AreaTable:
                    HasTool = true;
                    break;
                case ToolType.Item:
                case ToolType.Totem:
                    if (ID != 0)
                    {
                        HasTool = ObjectManager.GetObjectsOfType<WoWItem>().Any(i => i.Entry == ID);
                    }
                    else
                    {
                        WoWItem item = ObjectManager.GetObjectsOfType<WoWItem>().FirstOrDefault(i => i.Name == Name);
                        if (item != null)
                        {
                            ID = item.Entry;
                            HasTool = true;
                        }
                        else
                            HasTool = false;
                    }
                    break;
            }
        }

        #region Nested type: ToolType

        internal enum ToolType
        {
            SpellFocus,
            AreaTable,
            Item,
            Totem
        }

        #endregion
    }

    #endregion

    #region SkillLineAbilityEntry

    [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)]
    internal struct SkillLineAbilityEntry
    {
        #region RecipeAquireMethod enum

        public enum RecipeAquireMethod
        {
            TrainerBuy,
            TrainerAuto,
            Quest
        }

        #endregion

        public uint Id;
        public SkillLine SkillLine;
        public uint SpellId;
        public uint ReqRaces;
        public uint ReqClasses;
        public uint ExclRaces;
        public uint ExclClasses;
        public int OrangeSkillLevel;
        public uint NextSpellId;
        public RecipeAquireMethod AquireMethod;
        public int GreySkillLevel;
        public int YellowSkillLevel;
        public int SkillPointsEarned;
        public int DisplayOrder;

        public override string ToString()
        {
            return
                string.Format(
                    "{0} SkillLine: {1},NextSpellId: {2},AquireMethod: {3},OrangeSkillLevel: {4},YellowSkillLevel: {5}\n\tGreenSkillLevel: {6},GreySkillLevel: {7},SkillPointsEarned: {8},DisplayOrder: {9}",
                    SpellId, SkillLine, NextSpellId, AquireMethod, OrangeSkillLevel, YellowSkillLevel,
                    (YellowSkillLevel + GreySkillLevel)/2, GreySkillLevel, SkillPointsEarned, DisplayOrder);
        }
    }

    #endregion
}